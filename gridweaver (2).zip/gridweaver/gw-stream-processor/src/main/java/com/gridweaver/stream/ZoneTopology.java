package com.gridweaver.stream;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gridweaver.protocol.DeadLetter;
import com.gridweaver.protocol.DeviceType;
import com.gridweaver.protocol.TelemetryMessage;
import com.gridweaver.protocol.Topics;
import com.gridweaver.protocol.ZoneAggregate;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.utils.Bytes;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.*;
import org.apache.kafka.streams.state.KeyValueStore;

/**
 * telemetry.raw (key=deviceId)
 *   -> unusable frames go to telemetry.dlq (wrapped as DeadLetter)
 *   -> KTable "latest reading per device"
 *   -> groupBy zone, aggregate with add/subtract (an update replaces the device's old contribution)
 *   -> telemetry.zone-agg (key=zoneId)
 *
 * Why a KTable and not time windows: devices report ~1/s, so a 250 ms window would only ever see a
 * fraction of a zone's devices and the totals would be wrong. A table always reflects every device's
 * latest state; the commit interval (250 ms) just controls how often updated totals are emitted.
 *
 * Known limitation: a device that goes silent stays in the table with its last value until
 * Phase 5 adds tombstones from the heartbeat monitor.
 */
public final class ZoneTopology {
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private ZoneTopology() {}

    public static Topology build() {
        var telemetrySerde = new JsonSerde<>(TelemetryMessage.class);
        var aggSerde = new JsonSerde<>(ZoneAggregate.class);

        StreamsBuilder b = new StreamsBuilder();

        var branches = b
                .stream(Topics.TELEMETRY_RAW, Consumed.with(Serdes.String(), Serdes.String()))
                .split(Named.as("frames-"))
                .branch((deviceId, json) -> json != null && !usable(json), Branched.as("bad"))   // null = tombstone: passes through and deletes the device
                .defaultBranch(Branched.as("ok"));

        branches.get("frames-bad")
                .mapValues(ZoneTopology::deadLetterJson)
                .to(Topics.TELEMETRY_DLQ, Produced.with(Serdes.String(), Serdes.String()));

        KTable<String, TelemetryMessage> latest = branches.get("frames-ok")
                .mapValues(ZoneTopology::parse)
                .toTable(Materialized.<String, TelemetryMessage, KeyValueStore<Bytes, byte[]>>as("latest-device")
                        .withKeySerde(Serdes.String())
                        .withValueSerde(telemetrySerde));

        KTable<String, ZoneAggregate> zones = latest
                .groupBy((deviceId, t) -> KeyValue.pair(t.zoneId(), t), Grouped.with(Serdes.String(), telemetrySerde))
                .aggregate(
                        ZoneAggregate::empty,
                        (zone, t, agg) -> agg.add(t),
                        (zone, t, agg) -> agg.subtract(t),
                        Materialized.<String, ZoneAggregate, KeyValueStore<Bytes, byte[]>>as("zone-agg")
                                .withKeySerde(Serdes.String())
                                .withValueSerde(aggSerde));

        zones.toStream().to(Topics.ZONE_AGG, Produced.with(Serdes.String(), aggSerde));
        return b.build();
    }

    /** Parses AND is a device type that contributes to zone totals. */
    private static boolean usable(String json) {
        TelemetryMessage t = parse(json);
        return t != null && t.isValid()
                && (t.type() == DeviceType.SOLAR || t.type() == DeviceType.BATTERY || t.type() == DeviceType.METER);
    }

    private static TelemetryMessage parse(String json) {
        try { return MAPPER.readValue(json, TelemetryMessage.class); }
        catch (Exception e) { return null; }
    }

    private static String deadLetterJson(String payload) {
        try { return MAPPER.writeValueAsString(DeadLetter.of("stream-processor", "unparseable or invalid frame", payload)); }
        catch (Exception e) { return "{}"; }
    }
}
