package com.gridweaver.stream;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.errors.StreamsUncaughtExceptionHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Properties;

@Component
public class StreamsRunner {
    private static final Logger log = LoggerFactory.getLogger(StreamsRunner.class);
    private KafkaStreams streams;

    @Value("${spring.kafka.bootstrap-servers}") private String bootstrap;
    @Value("${gridweaver.streams.application-id}") private String appId;
    @Value("${gridweaver.streams.commit-interval-ms}") private int commitMs;
    @Value("${gridweaver.streams.threads}") private int threads;

    @PostConstruct
    void start() {
        Properties p = new Properties();
        p.put(StreamsConfig.APPLICATION_ID_CONFIG, appId);
        p.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        p.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.StringSerde.class);
        p.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.StringSerde.class);
        p.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, commitMs);          // emission cadence
        p.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, threads);
        p.put(StreamsConfig.STATESTORE_CACHE_MAX_BYTES_CONFIG, 10 * 1024 * 1024L);
        p.put(StreamsConfig.consumerPrefix(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG), "latest");

        streams = new KafkaStreams(ZoneTopology.build(), p);
        streams.setUncaughtExceptionHandler(ex -> {
            log.error("stream thread failed", ex);
            return StreamsUncaughtExceptionHandler.StreamThreadExceptionResponse.REPLACE_THREAD;
        });
        streams.start();
        log.info("zone aggregation streams started (commit interval {} ms)", commitMs);
    }

    @PreDestroy
    void stop() {
        if (streams != null) streams.close(Duration.ofSeconds(5));
    }
}
