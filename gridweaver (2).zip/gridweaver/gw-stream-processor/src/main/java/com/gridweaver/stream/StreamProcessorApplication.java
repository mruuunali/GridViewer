package com.gridweaver.stream;

import com.gridweaver.protocol.Topics;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.config.TopicConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.config.TopicBuilder;

@SpringBootApplication
public class StreamProcessorApplication {
    public static void main(String[] args) { SpringApplication.run(StreamProcessorApplication.class, args); }

    // Same definition as gw-ingestion: whichever service starts first creates the topic.
    @Bean NewTopic telemetryRaw() {
        return TopicBuilder.name(Topics.TELEMETRY_RAW).partitions(12).replicas(1)
                .config(TopicConfig.RETENTION_MS_CONFIG, String.valueOf(24 * 3600 * 1000L))
                .config(TopicConfig.SEGMENT_MS_CONFIG, String.valueOf(3600 * 1000L))
                .build();
    }
    @Bean NewTopic telemetryDlq() {
        return TopicBuilder.name(Topics.TELEMETRY_DLQ).partitions(3).replicas(1)
                .config(TopicConfig.RETENTION_MS_CONFIG, String.valueOf(7 * 24 * 3600 * 1000L)).build();
    }
    @Bean NewTopic zoneAgg()      { return TopicBuilder.name(Topics.ZONE_AGG).partitions(6).replicas(1).build(); }
}
