// Fake dashboard gateway that replays a localized storm WITH neighbour loans, so the UI works without Kafka/Java.
//   npm run mock     (ws://localhost:8090/ws/dashboard  +  http://localhost:8090/api/zones/:id/history)
// 70 s loop: 10 s storm hits zones 0..STORM_ZONES-1 (solar -> 10%); those zones go EMERGENCY ~1 s later,
// batteries discharge, and zones that border a sunny zone borrow one of its batteries (animated flow line).
// 40 s storm ends -> RECOVERING (loans released), 48 s -> NORMAL.
import { createServer } from 'node:http';
import { WebSocketServer } from 'ws';

const PORT = 8090, ZONES = 50, COLS = 10, TICK = 250, LOOP = 70_000, STORM_ZONES = 15;
const rnd = (a, b) => a + Math.random() * (b - a);

const history = new Map();
const http = createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  const m = /^\/api\/zones\/([^/]+)\/history/.exec(req.url ?? '');
  if (!m) { res.statusCode = 404; return res.end(); }
  const secs = Number(new URL(req.url, 'http://x').searchParams.get('seconds') ?? 120);
  const cutoff = Date.now() - secs * 1000;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify((history.get(m[1]) ?? []).filter((x) => x.ts >= cutoff)));
});
const wss = new WebSocketServer({ server: http, path: '/ws/dashboard' });
http.listen(PORT);

const neighbours = (z) => {
  const col = z % COLS, out = [];
  if (z - COLS >= 0) out.push(z - COLS);
  if (z + COLS < ZONES) out.push(z + COLS);
  if (col > 0) out.push(z - 1);
  if (col < COLS - 1) out.push(z + 1);
  return out;
};

const zones = Array.from({ length: ZONES }, (_, z) => {
  const storm = z < STORM_ZONES;
  const lender = storm ? neighbours(z).find((n) => n >= STORM_ZONES) : undefined;   // first sunny neighbour
  return {
    idx: z, id: `zone-${z}`, state: 'NORMAL', storm, lender, delay: rnd(400, 1600),
    gen0: 18000 + rnd(-1500, 1500), con0: 8000 + rnd(-800, 800),
    discharging: false, lending: false, borrowing: false,
    batteries: [`dev-${z}`, `dev-${z + 250}`],
  };
});
const recent = [];
const active = new Map();   // key from>to -> transfer
let t0 = Date.now(), lastSample = 0;

const view = (z, now, stormOn) => {
  const gen = z.gen0 * (z.storm && stormOn ? 0.1 : 1) * rnd(0.97, 1.03);
  const con = z.con0 * rnd(0.97, 1.03);
  const dis = (z.discharging ? 4000 : 0) + (z.lending ? 2000 : 0);
  return { id: z.id, state: z.state, generationW: gen, consumptionW: con, dischargeW: dis, chargeW: 0,
    loadRatio: con / Math.max(gen, 1), solar: 6, battery: 2, meter: 2, lastIngestAt: now - Math.round(rnd(20, 60)) };
};

const entry = (kind, subject, from, to, trigger, reason) => {
  const e = { ts: Date.now(), kind, subject, from, to, trigger, reason };
  recent.push(e); if (recent.length > 200) recent.shift();
  return e;
};

function tick() {
  const now = Date.now();
  const t = (now - t0) % LOOP;
  const stormOn = t >= 10_000 && t < 40_000;
  const nodes = [], log = [], transfers = [];

  for (const z of zones) {
    if (!z.storm) continue;
    if (stormOn && z.state === 'NORMAL' && t - 10_000 > z.delay) {
      z.state = 'EMERGENCY'; z.discharging = true;
      log.push(entry('ZONE', z.id, 'NORMAL', 'EMERGENCY', 'load/deficit', 'load exceeds generation'));
      for (const b of z.batteries) {
        nodes.push({ id: b, state: 'DISCHARGING', zone: z.id });
        log.push(entry('DEVICE', b, 'IDLE', 'DISCHARGING', 'GRID_DEFICIT', `zone dispatch ${z.id}`));
      }
      if (z.lender !== undefined) {          // own batteries cannot cover the deficit -> borrow
        const l = zones[z.lender];
        l.lending = true;
        nodes.push({ id: l.batteries[0], state: 'DISCHARGING', zone: l.id });
        log.push(entry('DEVICE', l.batteries[0], 'IDLE', 'DISCHARGING', 'GRID_DEFICIT', `loan ${l.id} -> ${z.id}`));
        const tr = { from: l.id, to: z.id, powerW: 2000, batteries: 1, active: true, ts: now };
        active.set(`${l.id}>${z.id}`, tr); transfers.push(tr);
        log.push(entry('TRANSFER', `${l.id} -> ${z.id}`, '-', 'ACTIVE', 'NEIGHBOUR_LOAN', '1 batteries, 2000 W'));
      }
    } else if (!stormOn && z.state === 'EMERGENCY') {
      z.state = 'RECOVERING'; z.discharging = false;
      log.push(entry('ZONE', z.id, 'EMERGENCY', 'RECOVERING', 'load/deficit', 'generation restored'));
      for (const b of z.batteries) {
        nodes.push({ id: b, state: 'IDLE', zone: z.id });
        log.push(entry('DEVICE', b, 'DISCHARGING', 'IDLE', 'GRID_NORMAL', `zone dispatch ${z.id}`));
      }
      if (z.lender !== undefined) {
        const l = zones[z.lender];
        l.lending = false;
        nodes.push({ id: l.batteries[0], state: 'IDLE', zone: l.id });
        log.push(entry('DEVICE', l.batteries[0], 'DISCHARGING', 'IDLE', 'GRID_NORMAL', `loan ended ${l.id} -> ${z.id}`));
        active.delete(`${l.id}>${z.id}`);
        transfers.push({ from: l.id, to: z.id, powerW: 0, batteries: 0, active: false, ts: now });
        log.push(entry('TRANSFER', `${l.id} -> ${z.id}`, 'ACTIVE', 'ENDED', 'NEIGHBOUR_LOAN', 'loan released'));
      }
    } else if (!stormOn && z.state === 'RECOVERING' && t > 48_000) {
      z.state = 'NORMAL';
      log.push(entry('ZONE', z.id, 'RECOVERING', 'NORMAL', 'recovery hold', 'stable'));
    }
  }

  const views = zones.map((z) => view(z, now, stormOn));
  if (now - lastSample >= 1000) {
    lastSample = now;
    for (const v of views) {
      const arr = history.get(v.id) ?? [];
      arr.push({ ts: now, state: v.state, generationW: v.generationW, consumptionW: v.consumptionW, dischargeW: v.dischargeW, loadRatio: v.loadRatio });
      if (arr.length > 600) arr.shift();
      history.set(v.id, arr);
    }
  }
  const json = JSON.stringify({ type: 'delta', ts: now, zones: views, nodes, log, transfers });
  for (const c of wss.clients) if (c.readyState === 1) c.send(json);
}

wss.on('connection', (ws) => {
  const now = Date.now(), t = (now - t0) % LOOP, stormOn = t >= 10_000 && t < 40_000;
  const nodes = zones.flatMap((z) => [
    ...z.batteries.map((b, i) => ({ id: b, state: (z.discharging || (i === 0 && z.lending)) ? 'DISCHARGING' : 'IDLE', zone: z.id })),
  ]);
  ws.send(JSON.stringify({ type: 'snapshot', ts: now, zones: zones.map((z) => view(z, now, stormOn)), nodes, log: recent, transfers: [...active.values()] }));
});

setInterval(tick, TICK);
console.log(`mock gateway: ws://localhost:${PORT}/ws/dashboard (storm zones 0-${STORM_ZONES - 1} at 10s, ends 40s, loops every 70s)`);
