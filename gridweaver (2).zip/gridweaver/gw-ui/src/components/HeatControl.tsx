import type { HeatMode } from '../types';

const MODES: { id: HeatMode; label: string; hint: string }[] = [
  { id: 'consumption', label: 'Consumption', hint: 'Where demand is high' },
  { id: 'generation', label: 'Generation', hint: 'Where solar output is high' },
  { id: 'net', label: 'Net balance', hint: 'Red = shortfall, green = surplus' },
  { id: 'off', label: 'Off', hint: 'Hide heatmap' },
];

export function HeatControl({ mode, onChange }: { mode: HeatMode; onChange: (m: HeatMode) => void }) {
  const active = MODES.find((m) => m.id === mode)!;
  return (
    <div className="panel heatctl">
      <h4>Heatmap</h4>
      <div className="seg">
        {MODES.map((m) => (
          <button key={m.id} className={m.id === mode ? 'on' : ''} onClick={() => onChange(m.id)}>
            {m.label}
          </button>
        ))}
      </div>
      <div className="muted">{active.hint}</div>
    </div>
  );
}
