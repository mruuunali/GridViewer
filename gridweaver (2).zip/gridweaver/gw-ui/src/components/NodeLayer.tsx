import { useEffect } from 'react';
import L from 'leaflet';
import { useMap } from 'react-leaflet';
import type { GridStore } from '../gridStore';
import { nodeColor } from '../theme';
import type { GridNode } from '../types';

const label = (n: GridNode, state: string) => `${n.id} · ${n.type} · ${state} · ${n.zoneId}`;

/**
 * One shared <canvas> for all markers. Live updates restyle ONLY the markers whose state changed
 * (store.drainDirtyNodes), straight from the store subscription, bypassing React re-renders.
 */
export function NodeLayer({ nodes, store }: { nodes: GridNode[]; store: GridStore }) {
  const map = useMap();

  useEffect(() => {
    const renderer = L.canvas({ padding: 0.5 });
    const group = L.layerGroup();
    const markers = new Map<string, L.CircleMarker>();
    const byId = new Map(nodes.map((n) => [n.id, n]));

    for (const n of nodes) {
      const state = store.nodeState.get(n.id) ?? n.state;
      const marker = L.circleMarker([n.lat, n.lng], {
        renderer,
        radius: n.type === 'BATTERY' ? 5.5 : n.type === 'METER' ? 3 : 3.5,
        color: '#ffffff',
        weight: n.type === 'BATTERY' ? 1.4 : 0.8,
        fillColor: nodeColor(n.type, state),
        fillOpacity: 0.92,
      });
      marker.bindTooltip(label(n, state), { direction: 'top' });
      markers.set(n.id, marker);
      group.addLayer(marker);
    }
    group.addTo(map);

    const applyChanges = () => {
      for (const id of store.drainDirtyNodes()) {
        const marker = markers.get(id);
        const node = byId.get(id);
        const state = store.nodeState.get(id);
        if (!marker || !node || !state) continue;
        marker.setStyle({ fillColor: nodeColor(node.type, state) });
        marker.setTooltipContent(label(node, state));
      }
    };
    applyChanges();
    const unsubscribe = store.subscribe(applyChanges);

    return () => { unsubscribe(); group.remove(); };
  }, [map, nodes, store]);

  return null;
}
