import { Rectangle, Tooltip } from 'react-leaflet';
import type { GridStore } from '../gridStore';
import { ZONE_STATE_COLOR } from '../theme';
import type { Zone } from '../types';

const kw = (w: number) => `${(w / 1000).toFixed(1)} kW`;

export function ZoneLayer({ zones, store, selected, onSelect }: {
  zones: Zone[]; store: GridStore; selected: string | null; onSelect: (id: string) => void;
}) {
  return (
    <>
      {zones.map((z) => {
        const v = store.zoneView.get(z.id);
        const state = v?.state ?? 'NORMAL';
        const color = ZONE_STATE_COLOR[state];
        const hot = state === 'EMERGENCY' || state === 'STRESSED';
        const isSel = z.id === selected;
        return (
          <Rectangle
            key={z.id}
            bounds={z.bounds}
            eventHandlers={{ click: () => onSelect(z.id) }}
            pathOptions={{
              color: isSel ? '#ffffff' : color,
              weight: isSel ? 3 : hot ? 2.5 : 1.5,
              fillColor: color,
              fillOpacity: hot ? 0.18 : 0.04,
            }}
          >
            <Tooltip sticky>
              <b>{z.id}</b> · {state}
              {v && (<><br />gen {kw(v.generationW)} · load {kw(v.consumptionW)}<br />click for details</>)}
            </Tooltip>
          </Rectangle>
        );
      })}
    </>
  );
}
