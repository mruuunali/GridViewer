import type { GridStore } from '../gridStore';

/** Compact live feed. The full, filterable Event Log panel is Week 4. */
export function EventTicker({ store }: { store: GridStore }) {
  const rows = store.log.slice(0, 8);
  return (
    <div className="panel ticker">
      <h4>Latest transitions</h4>
      {rows.length === 0 && <div className="muted">Waiting for events…</div>}
      {rows.map((e, i) => (
        <div key={`${e.ts}-${e.subject}-${i}`} className={`tick ${e.kind === 'ZONE' ? 'zone' : e.kind === 'TRANSFER' ? 'transfer' : ''}`}>
          <span className="muted">{new Date(e.ts).toLocaleTimeString()}</span>{' '}
          <b>{e.subject}</b> {e.from} → {e.to}
        </div>
      ))}
    </div>
  );
}
