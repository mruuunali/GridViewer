import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet.heat';
import { useMap } from 'react-leaflet';
import type { GridStore } from '../gridStore';
import type { GridNode, HeatMode } from '../types';

type HeatPoint = [number, number, number];

const GRADIENTS = {
  consumption: { 0.2: '#3b1f6b', 0.5: '#8e44ad', 0.8: '#e84393', 1.0: '#ff3b3b' },
  generation: { 0.2: '#5a4300', 0.5: '#d4a017', 0.8: '#f5d300', 1.0: '#fffbe0' },
  deficit: { 0.2: '#5c1a1a', 0.6: '#ee5253', 1.0: '#ffd1d1' },
  surplus: { 0.2: '#0b4d3a', 0.6: '#10ac84', 1.0: '#d1ffee' },
};

/**
 * Heat is per ZONE (what the backend reports), spread over that zone's node positions.
 * Intensity is normalised against the highest value seen so far, so when a storm cuts generation
 * the glow visibly shrinks instead of being rescaled back to full brightness.
 */
export function HeatLayer({ nodes, store, mode }: { nodes: GridNode[]; store: GridStore; mode: HeatMode }) {
  const map = useMap();
  const peak = useRef({ gen: 1, con: 1, net: 1 });

  useEffect(() => {
    if (mode === 'off') return;
    const byZone = new Map<string, GridNode[]>();
    for (const n of nodes) {
      const list = byZone.get(n.zoneId) ?? [];
      list.push(n);
      byZone.set(n.zoneId, list);
    }

    const make = (grad: Record<number, string>) =>
      (L as unknown as { heatLayer: (p: HeatPoint[], o: object) => L.Layer & { setLatLngs: (p: HeatPoint[]) => void } })
        .heatLayer([], { radius: 38, blur: 28, maxZoom: 15, minOpacity: 0.05, gradient: grad });

    const primary = make(mode === 'net' ? GRADIENTS.deficit : GRADIENTS[mode]);
    const secondary = mode === 'net' ? make(GRADIENTS.surplus) : null;
    primary.addTo(map);
    secondary?.addTo(map);

    const refresh = () => {
      const a: HeatPoint[] = [];
      const b: HeatPoint[] = [];
      const p = peak.current;
      for (const [zoneId, zoneNodes] of byZone) {
        const v = store.zoneView.get(zoneId);
        if (!v) continue;
        p.gen = Math.max(p.gen, v.generationW);
        p.con = Math.max(p.con, v.consumptionW);
        const net = v.generationW - v.consumptionW;
        p.net = Math.max(p.net, Math.abs(net));
        let ia = 0, ib = 0;
        if (mode === 'consumption') ia = v.consumptionW / p.con;
        else if (mode === 'generation') ia = v.generationW / p.gen;
        else { ia = net < 0 ? -net / p.net : 0; ib = net > 0 ? net / p.net : 0; }
        for (const n of zoneNodes) {
          if (ia > 0.01) a.push([n.lat, n.lng, ia]);
          if (ib > 0.01) b.push([n.lat, n.lng, ib]);
        }
      }
      primary.setLatLngs(a);
      secondary?.setLatLngs(b);
    };
    refresh();
    const unsubscribe = store.subscribe(refresh);   // <= 5 Hz, one redraw per gateway batch

    return () => { unsubscribe(); primary.remove(); secondary?.remove(); };
  }, [map, nodes, store, mode]);

  return null;
}
