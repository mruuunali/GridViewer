import { BATTERY_STATE_COLOR, METER_COLOR, SOLAR_COLOR, ZONE_STATE_COLOR } from '../theme';

function Dot({ color }: { color: string }) {
  return <span className="dot" style={{ background: color }} />;
}

export function Legend() {
  return (
    <div className="panel legend">
      <h4>Legend</h4>
      <div><Dot color={SOLAR_COLOR} /> Solar</div>
      <div><Dot color={METER_COLOR} /> Meter (load)</div>
      <div className="muted">Battery</div>
      {Object.entries(BATTERY_STATE_COLOR).map(([s, c]) => (
        <div key={s}><Dot color={c} /> {s.charAt(0) + s.slice(1).toLowerCase()}</div>
      ))}
      <hr />
      <div><span className="flowkey" /> Power loan <span className="muted">(lender → borrower)</span></div>
      <hr />
      <div className="muted">Zone outline</div>
      {Object.entries(ZONE_STATE_COLOR).map(([s, c]) => (
        <div key={s}><Dot color={c} /> {s}</div>
      ))}
    </div>
  );
}
