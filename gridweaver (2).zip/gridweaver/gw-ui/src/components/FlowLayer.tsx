import { useEffect } from 'react';
import L from 'leaflet';
import { useMap } from 'react-leaflet';
import type { GridStore } from '../gridStore';
import type { Zone } from '../types';

const PANE = 'flows';

/**
 * Animated power-flow lines between zones: lender -> borrower, width proportional to power.
 * Uses an SVG renderer in its own pane (the rest of the map is canvas) so the dashes can be animated
 * with CSS; only a handful of loans exist at once, so SVG cost is irrelevant here.
 */
export function FlowLayer({ zones, store }: { zones: Zone[]; store: GridStore }) {
  const map = useMap();

  useEffect(() => {
    if (!map.getPane(PANE)) {
      const pane = map.createPane(PANE);
      pane.style.zIndex = '450';
      pane.style.pointerEvents = 'none';
    }
    const renderer = L.svg({ pane: PANE });
    const centers = new Map(zones.map((z) => [z.id, L.latLngBounds(z.bounds).getCenter()]));
    const root = L.layerGroup().addTo(map);
    const shapes = new Map<string, L.FeatureGroup>();

    const sync = () => {
      const live = new Set<string>();
      for (const [key, t] of store.transfers) {
        const a = centers.get(t.from);
        const b = centers.get(t.to);
        if (!a || !b) continue;
        live.add(key);
        const weight = Math.min(10, 2 + t.powerW / 2000);
        const existing = shapes.get(key);
        if (existing) {
          existing.eachLayer((l) => { if (l instanceof L.Polyline && !(l instanceof L.Polygon)) l.setStyle({ weight }); });
          continue;
        }
        const line = L.polyline([a, b], {
          renderer, className: 'flow-line', color: '#00d2d3', weight, opacity: 0.95, dashArray: '10 12', interactive: false,
        });
        const source = L.circleMarker(a, { renderer, radius: 6, color: '#fff', weight: 1.5, fillColor: '#10ac84', fillOpacity: 1, interactive: false });
        const sink = L.circleMarker(b, { renderer, radius: 6, color: '#fff', weight: 1.5, fillColor: '#ee5253', fillOpacity: 1, interactive: false });
        const fg = L.featureGroup([line, source, sink]);
        root.addLayer(fg);
        shapes.set(key, fg);
      }
      for (const [key, fg] of shapes) {
        if (!live.has(key)) { root.removeLayer(fg); shapes.delete(key); }
      }
    };

    sync();
    const unsubscribe = store.subscribe(sync);
    return () => { unsubscribe(); root.remove(); };
  }, [map, zones, store]);

  return null;
}
