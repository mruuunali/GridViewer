import type { GridStore } from '../gridStore';
import { ZONE_STATE_COLOR } from '../theme';
import type { ZoneState } from '../types';

const kw = (w: number) => (w / 1000).toFixed(1);

export function StatsPanel({ store, nodeCount }: { store: GridStore; nodeCount: number }) {
  const t = store.totals();
  const states = Object.keys(ZONE_STATE_COLOR) as ZoneState[];
  return (
    <div className="panel stats">
      <h4>Grid</h4>
      <div><b>{nodeCount}</b> nodes · <b>{store.zoneView.size}</b> zones reporting</div>
      <hr />
      <div>Generation <b>{kw(t.gen)}</b> kW</div>
      <div>Load <b>{kw(t.con)}</b> kW</div>
      <div>Battery out <b>{kw(t.dis)}</b> kW</div>
      <div>Zone loans <b>{store.transfers.size}</b> active</div>
      <hr />
      {states.map((s) => (
        <div key={s} className="row">
          <span><span className="dot" style={{ background: ZONE_STATE_COLOR[s] }} />{s}</span>
          <b>{t.byState[s] ?? 0}</b>
        </div>
      ))}
    </div>
  );
}
