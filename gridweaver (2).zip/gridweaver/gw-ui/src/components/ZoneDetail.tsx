import { useEffect, useState } from 'react';
import { GATEWAY_HTTP } from '../config';
import type { GridStore } from '../gridStore';
import { ZONE_STATE_COLOR } from '../theme';
import type { HistorySample } from '../types';

const kw = (w: number) => `${(w / 1000).toFixed(1)} kW`;
const W = 280, H = 90, SECONDS = 120;

function Chart({ samples }: { samples: HistorySample[] }) {
  if (samples.length < 2) return <div className="muted">Collecting history…</div>;
  const t0 = samples[0].ts, t1 = samples[samples.length - 1].ts || t0 + 1;
  const max = Math.max(1, ...samples.map((s) => Math.max(s.generationW, s.consumptionW)));
  const x = (t: number) => ((t - t0) / Math.max(1, t1 - t0)) * W;
  const y = (v: number) => H - (v / max) * (H - 6) - 3;
  const path = (f: (s: HistorySample) => number) =>
    samples.map((s, i) => `${i ? 'L' : 'M'}${x(s.ts).toFixed(1)},${y(f(s)).toFixed(1)}`).join(' ');
  return (
    <svg width={W} height={H} role="img" aria-label="Generation, load and battery output, last 2 minutes">
      <path d={path((s) => s.generationW)} fill="none" stroke="#f5b301" strokeWidth="2" />
      <path d={path((s) => s.consumptionW)} fill="none" stroke="#8e44ad" strokeWidth="2" />
      <path d={path((s) => s.dischargeW)} fill="none" stroke="#ee5253" strokeWidth="1.5" strokeDasharray="4 3" />
    </svg>
  );
}

export function ZoneDetail({ zoneId, store, onClose }: { zoneId: string; store: GridStore; onClose: () => void }) {
  const [history, setHistory] = useState<HistorySample[]>([]);
  const [error, setError] = useState(false);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const r = await fetch(`${GATEWAY_HTTP}/api/zones/${zoneId}/history?seconds=${SECONDS}`);
        if (!r.ok) throw new Error(String(r.status));
        const data = (await r.json()) as HistorySample[];
        if (alive) { setHistory(data); setError(false); }
      } catch {
        if (alive) setError(true);
      }
    };
    setHistory([]);
    load();
    const id = setInterval(load, 2000);
    return () => { alive = false; clearInterval(id); };
  }, [zoneId]);

  const v = store.zoneView.get(zoneId);
  const deficit = v ? Math.max(0, v.consumptionW - v.generationW) : 0;

  return (
    <div className="panel detail">
      <div className="row">
        <h4>{zoneId}</h4>
        <button className="x" onClick={onClose} aria-label="Close zone detail">×</button>
      </div>
      {!v ? <div className="muted">No data for this zone yet.</div> : (
        <>
          <div>
            <span className="dot" style={{ background: ZONE_STATE_COLOR[v.state] }} /> <b>{v.state}</b>
            <span className="muted"> · load ratio {v.loadRatio.toFixed(2)}</span>
          </div>
          <div className="grid2">
            <span>Generation</span><b>{kw(v.generationW)}</b>
            <span>Consumption</span><b>{kw(v.consumptionW)}</b>
            <span>Deficit</span><b>{kw(deficit)}</b>
            <span>Battery output</span><b>{kw(v.dischargeW)}</b>
            <span>Batteries</span><b>{v.battery}</b>
            <span>Solar / meters</span><b>{v.solar} / {v.meter}</b>
          </div>
        </>
      )}
      <hr />
      <div className="muted">Last 2 min</div>
      {error ? <div className="muted">History unavailable (gateway /api not reachable).</div> : <Chart samples={history} />}
      <div className="muted keyline">
        <span style={{ color: '#f5b301' }}>━</span> generation <span style={{ color: '#8e44ad' }}>━</span> load{' '}
        <span style={{ color: '#ee5253' }}>╌</span> battery
      </div>
    </div>
  );
}
