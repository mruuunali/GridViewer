import { useMemo, useState } from 'react';
import type { GridStore } from '../gridStore';
import type { LogEntry } from '../types';

type Kind = LogEntry['kind'];
const KINDS: { id: Kind; label: string }[] = [
  { id: 'ZONE', label: 'Zones' },
  { id: 'DEVICE', label: 'Batteries' },
  { id: 'TRANSFER', label: 'Transfers' },
];
const SHOWN = 300;

const csvCell = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;

function exportCsv(rows: LogEntry[]) {
  const head = ['time_iso', 'kind', 'subject', 'from', 'to', 'trigger', 'reason'];
  const lines = [head.join(',')].concat(
    rows.map((e) => [new Date(e.ts).toISOString(), e.kind, e.subject, e.from, e.to, e.trigger, e.reason].map(csvCell).join(',')),
  );
  const url = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/csv' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = `gridweaver-event-log-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

/** Audit view of every state transition: filter, search, pause, export. Newest first. */
export function EventLog({ store, onClose }: { store: GridStore; onClose: () => void }) {
  const [kinds, setKinds] = useState<Set<Kind>>(new Set(['ZONE', 'DEVICE', 'TRANSFER']));
  const [query, setQuery] = useState('');
  const [frozen, setFrozen] = useState<LogEntry[] | null>(null);   // snapshot while paused; the store keeps collecting

  const source = frozen ?? store.log;
  const q = query.trim().toLowerCase();
  const filtered = useMemo(
    () => source.filter((e) =>
      kinds.has(e.kind) &&
      (!q || `${e.subject} ${e.from} ${e.to} ${e.trigger} ${e.reason}`.toLowerCase().includes(q))),
    [source, kinds, q],
  );
  const pending = frozen ? Math.max(0, store.log.length - frozen.length) : 0;

  const toggle = (k: Kind) => {
    const next = new Set(kinds);
    if (next.has(k)) next.delete(k); else next.add(k);
    setKinds(next);
  };

  return (
    <div className="panel eventlog">
      <div className="row">
        <h4>Event log <span className="muted">· {filtered.length} entries</span></h4>
        <button className="x" onClick={onClose} aria-label="Close event log">×</button>
      </div>

      <div className="logbar">
        {KINDS.map((k) => (
          <label key={k.id}><input type="checkbox" checked={kinds.has(k.id)} onChange={() => toggle(k.id)} /> {k.label}</label>
        ))}
        <input className="search" placeholder="Search zone, device, trigger…" value={query}
               onChange={(e) => setQuery(e.target.value)} aria-label="Search the event log" />
        <button onClick={() => setFrozen(frozen ? null : [...store.log])}>
          {frozen ? `Resume${pending ? ` (+${pending})` : ''}` : 'Pause'}
        </button>
        <button onClick={() => exportCsv(filtered)} disabled={filtered.length === 0}>Export CSV</button>
      </div>

      <div className="logscroll">
        <table>
          <thead><tr><th>Time</th><th>Type</th><th>Subject</th><th>Transition</th><th>Trigger</th><th>Reason</th></tr></thead>
          <tbody>
            {filtered.slice(0, SHOWN).map((e, i) => (
              <tr key={`${e.ts}-${e.subject}-${i}`} className={e.kind.toLowerCase()}>
                <td className="muted">{new Date(e.ts).toLocaleTimeString()}</td>
                <td>{e.kind === 'DEVICE' ? 'Battery' : e.kind === 'ZONE' ? 'Zone' : 'Transfer'}</td>
                <td><b>{e.subject}</b></td>
                <td>{e.from} → {e.to}</td>
                <td>{e.trigger}</td>
                <td className="muted">{e.reason}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <div className="muted pad">No matching events yet.</div>}
        {filtered.length > SHOWN && <div className="muted pad">Showing newest {SHOWN} of {filtered.length}. Export CSV for all.</div>}
      </div>
    </div>
  );
}
