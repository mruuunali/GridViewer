import { GATEWAY_URL } from './config';
import type { GridStore } from './gridStore';
import type { GatewayMessage } from './types';

/** Connects to the dashboard gateway and reconnects with backoff. Returns a cleanup function. */
export function connectGateway(store: GridStore): () => void {
  let ws: WebSocket | null = null;
  let closed = false;
  let attempt = 0;
  let timer: ReturnType<typeof setTimeout> | undefined;

  const open = () => {
    store.setStatus('connecting');
    ws = new WebSocket(GATEWAY_URL);
    ws.onopen = () => { attempt = 0; store.setStatus('live'); };
    ws.onmessage = (e) => {
      try { store.apply(JSON.parse(e.data as string) as GatewayMessage); } catch { /* ignore bad frame */ }
    };
    ws.onerror = () => ws?.close();
    ws.onclose = () => {
      if (closed) return;
      store.setStatus('disconnected');
      timer = setTimeout(open, Math.min(5000, 500 * 2 ** attempt++));
    };
  };

  open();
  return () => {
    closed = true;
    if (timer) clearTimeout(timer);
    ws?.close();
  };
}
