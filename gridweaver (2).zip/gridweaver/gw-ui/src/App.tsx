import { useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import { connectGateway } from './connectGateway';
import { EventLog } from './components/EventLog';
import { EventTicker } from './components/EventTicker';
import { FlowLayer } from './components/FlowLayer';
import { HeatControl } from './components/HeatControl';
import { HeatLayer } from './components/HeatLayer';
import { Legend } from './components/Legend';
import { NodeLayer } from './components/NodeLayer';
import { StatsPanel } from './components/StatsPanel';
import { ZoneDetail } from './components/ZoneDetail';
import { ZoneLayer } from './components/ZoneLayer';
import { MAP_CENTER, MAP_ZOOM } from './config';
import { GridStore } from './gridStore';
import { buildMockCity } from './mock/cityGrid';
import type { HeatMode } from './types';

const STATUS_LABEL = { connecting: 'Connecting…', live: 'Live', disconnected: 'Disconnected · retrying' } as const;

export default function App() {
  const { zones, nodes } = useMemo(buildMockCity, []);
  const store = useMemo(() => new GridStore(), []);
  const [heat, setHeat] = useState<HeatMode>('net');
  const [selected, setSelected] = useState<string | null>(null);
  const [logOpen, setLogOpen] = useState(false);

  useEffect(() => connectGateway(store), [store]);
  useSyncExternalStore(store.subscribe, store.getVersion);   // re-render on every gateway batch (<= 5 Hz)

  return (
    <div className="app">
      <header className="topbar">
        <strong>GridWeaver</strong>
        <span className="muted">Microgrid operations dashboard</span>
        <span className="spacer" />
        {store.status === 'live' && store.latencyMs > 0 && (
          <span className="badge" title="Newest zone data: device ingestion to this browser">
            data age {store.latencyMs} ms
          </span>
        )}
        <button className={`topbtn ${logOpen ? 'on' : ''}`} onClick={() => setLogOpen(!logOpen)}>
          Event log{store.log.length > 0 ? ` (${store.log.length})` : ''}
        </button>
        <span className={`badge ${store.status}`}>{STATUS_LABEL[store.status]}</span>
      </header>

      <div className="map-wrap">
        <MapContainer center={MAP_CENTER} zoom={MAP_ZOOM} preferCanvas className="map">
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <HeatLayer nodes={nodes} store={store} mode={heat} />
          <ZoneLayer zones={zones} store={store} selected={selected} onSelect={setSelected} />
          <NodeLayer nodes={nodes} store={store} />
          <FlowLayer zones={zones} store={store} />
        </MapContainer>

        <StatsPanel store={store} nodeCount={nodes.length} />
        <HeatControl mode={heat} onChange={setHeat} />
        {selected && <ZoneDetail zoneId={selected} store={store} onClose={() => setSelected(null)} />}
        <Legend />
        {logOpen ? <EventLog store={store} onClose={() => setLogOpen(false)} /> : <EventTicker store={store} />}
      </div>
    </div>
  );
}
