export type NodeType = 'SOLAR' | 'BATTERY' | 'METER';
export type BatteryState = 'IDLE' | 'CHARGING' | 'DISCHARGING' | 'FAULT' | 'OFFLINE';
export type ZoneState = 'NORMAL' | 'STRESSED' | 'EMERGENCY' | 'RECOVERING';

export interface GridNode {
  id: string;
  zoneId: string;
  type: NodeType;
  lat: number;
  lng: number;
  /** Batteries use BatteryState; solar and meter nodes are 'ONLINE'. */
  state: string;
}

/** Map geometry only. Live state/metrics come from the gateway (ZoneView). */
export interface Zone {
  id: string;
  /** [[south, west], [north, east]] */
  bounds: [[number, number], [number, number]];
}

// ---- gateway protocol (mirrors gw-dashboard-gateway Messages.java) ----
export interface ZoneView {
  id: string;
  state: ZoneState;
  generationW: number;
  consumptionW: number;
  dischargeW: number;
  chargeW: number;
  loadRatio: number;
  solar: number;
  battery: number;
  meter: number;
  lastIngestAt: number;
}

export interface NodeUpdate {
  id: string;
  state: string | null;
  zone: string | null;
}

export interface LogEntry {
  ts: number;
  kind: 'DEVICE' | 'ZONE' | 'TRANSFER';
  subject: string;
  from: string;
  to: string;
  trigger: string;
  reason: string;
}

export interface TransferView {
  from: string;
  to: string;
  powerW: number;
  batteries: number;
  active: boolean;
  ts: number;
}

export interface GatewayMessage {
  type: 'snapshot' | 'delta';
  ts: number;
  zones: ZoneView[];
  nodes: NodeUpdate[];
  log: LogEntry[];
  transfers?: TransferView[];
}

export interface HistorySample {
  ts: number;
  state: ZoneState;
  generationW: number;
  consumptionW: number;
  dischargeW: number;
  loadRatio: number;
}

export type HeatMode = 'consumption' | 'generation' | 'net' | 'off';
