/** Centre of the mock city. Change this to your own city; the grid is generated around it. */
export const MAP_CENTER: [number, number] = [51.5074, -0.1278];
export const MAP_ZOOM = 12;

export const GRID_COLS = 10;
export const GRID_ROWS = 5;
export const NODES_PER_ZONE = 10;   // 10 x 5 zones x 10 nodes = 500 nodes

export const GATEWAY_URL: string =
  import.meta.env.VITE_GATEWAY_URL ?? 'ws://localhost:8090/ws/dashboard';

/** HTTP base of the gateway (history API), derived from the WebSocket URL. */
export const GATEWAY_HTTP: string = GATEWAY_URL.replace(/^ws/, 'http').replace(/\/ws\/.*$/, '');
