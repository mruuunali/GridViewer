import { GRID_COLS, GRID_ROWS, MAP_CENTER, NODES_PER_ZONE } from '../config';
import type { GridNode, Zone } from '../types';

// Deterministic PRNG so the mock city looks the same on every reload.
function mulberry32(seed: number) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const CELL_LAT = 0.012;
const CELL_LNG = 0.018;

/**
 * Device ids follow the simulator exactly: dev-N, zone = N % 50, and slot = (N / 50) % 5
 * where slot 0 = battery, 1 = meter, 2..4 = solar. So each zone of 10 has 2 batteries, 2 meters, 6 solar,
 * and live updates from the gateway land on the right marker.
 */
export function buildMockCity(): { zones: Zone[]; nodes: GridNode[] } {
  const rand = mulberry32(42);
  const zones: Zone[] = [];
  const nodes: GridNode[] = [];

  const south0 = MAP_CENTER[0] - (GRID_ROWS * CELL_LAT) / 2;
  const west0 = MAP_CENTER[1] - (GRID_COLS * CELL_LNG) / 2;
  const zoneCount = GRID_COLS * GRID_ROWS;

  for (let z = 0; z < zoneCount; z++) {
    const col = z % GRID_COLS;
    const row = Math.floor(z / GRID_COLS);
    const south = south0 + row * CELL_LAT;
    const west = west0 + col * CELL_LNG;
    zones.push({ id: `zone-${z}`, bounds: [[south, west], [south + CELL_LAT, west + CELL_LNG]] });

    for (let k = 0; k < NODES_PER_ZONE; k++) {
      const idx = z + k * zoneCount;
      const slot = k % 5;
      const type = slot === 0 ? 'BATTERY' : slot === 1 ? 'METER' : 'SOLAR';
      nodes.push({
        id: `dev-${idx}`,
        zoneId: `zone-${z}`,
        type,
        lat: south + CELL_LAT * (0.08 + 0.84 * rand()),
        lng: west + CELL_LNG * (0.08 + 0.84 * rand()),
        state: type === 'BATTERY' ? 'IDLE' : 'ONLINE',
      });
    }
  }
  return { zones, nodes };
}
