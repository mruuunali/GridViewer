import type { GatewayMessage, LogEntry, TransferView, ZoneView } from './types';

const LOG_CAP = 2000;   // enough for a long storm; the Event Log can export it all

export type ConnStatus = 'connecting' | 'live' | 'disconnected';

/**
 * Mutable store that lives OUTSIDE React. Gateway messages mutate it and bump `version`;
 * React components read it via useSyncExternalStore (zones, panels), while the canvas layer
 * subscribes directly and restyles only the markers that changed (no React re-render per marker).
 */
export class GridStore {
  nodeState = new Map<string, string>();
  zoneView = new Map<string, ZoneView>();
  transfers = new Map<string, TransferView>();   // active neighbour loans, key = from>to
  log: LogEntry[] = [];            // newest first
  status: ConnStatus = 'connecting';
  latencyMs = 0;                   // newest zone data: ingestion -> this browser
  messages = 0;

  private dirtyNodes = new Set<string>();
  private listeners = new Set<() => void>();
  private version = 0;

  subscribe = (cb: () => void) => {
    this.listeners.add(cb);
    return () => { this.listeners.delete(cb); };
  };

  getVersion = () => this.version;

  setStatus(s: ConnStatus) {
    this.status = s;
    this.emit();
  }

  apply(msg: GatewayMessage) {
    this.messages++;
    const now = Date.now();
    let worst = 0;

    for (const z of msg.zones) {
      this.zoneView.set(z.id, z);
      if (z.lastIngestAt > 0) worst = Math.max(worst, now - z.lastIngestAt);
    }
    if (worst > 0) this.latencyMs = worst;

    for (const n of msg.nodes) {
      if (n.state == null) continue;
      this.nodeState.set(n.id, n.state);
      this.dirtyNodes.add(n.id);
    }

    if (msg.type === 'snapshot') this.transfers.clear();
    for (const t of msg.transfers ?? []) {
      const key = `${t.from}>${t.to}`;
      if (t.active) this.transfers.set(key, t); else this.transfers.delete(key);
    }

    if (msg.type === 'snapshot') {
      this.log = [...msg.log].reverse().slice(0, LOG_CAP);
    } else if (msg.log.length > 0) {
      this.log = [...[...msg.log].reverse(), ...this.log].slice(0, LOG_CAP);
    }
    this.emit();
  }

  drainDirtyNodes(): string[] {
    const ids = [...this.dirtyNodes];
    this.dirtyNodes.clear();
    return ids;
  }

  totals() {
    let gen = 0, con = 0, dis = 0;
    const byState: Record<string, number> = { NORMAL: 0, STRESSED: 0, EMERGENCY: 0, RECOVERING: 0 };
    for (const z of this.zoneView.values()) {
      gen += z.generationW; con += z.consumptionW; dis += z.dischargeW;
      byState[z.state] = (byState[z.state] ?? 0) + 1;
    }
    return { gen, con, dis, byState };
  }

  private emit() {
    this.version++;
    this.listeners.forEach((l) => l());
  }
}
