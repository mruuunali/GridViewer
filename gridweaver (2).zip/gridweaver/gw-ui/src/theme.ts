import type { NodeType, ZoneState } from './types';

export const SOLAR_COLOR = '#f5b301';
export const METER_COLOR = '#8e44ad';

export const BATTERY_STATE_COLOR: Record<string, string> = {
  IDLE: '#2e86de',
  CHARGING: '#10ac84',
  DISCHARGING: '#ee5253',
  FAULT: '#7b1113',
  OFFLINE: '#576574',
};

export const ZONE_STATE_COLOR: Record<ZoneState, string> = {
  NORMAL: '#10ac84',
  STRESSED: '#ff9f43',
  EMERGENCY: '#ee5253',
  RECOVERING: '#54a0ff',
};

export function nodeColor(type: NodeType, state: string): string {
  if (type === 'SOLAR') return SOLAR_COLOR;
  if (type === 'METER') return METER_COLOR;
  return BATTERY_STATE_COLOR[state] ?? BATTERY_STATE_COLOR.IDLE;
}
