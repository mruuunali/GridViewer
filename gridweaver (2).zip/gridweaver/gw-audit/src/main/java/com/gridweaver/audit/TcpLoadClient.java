package com.gridweaver.audit;

import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Opens N idle-ish connections (one ping per second each) from virtual threads, so the CLIENT is never
 * the bottleneck.   Usage: TcpLoadClient <connections> [host=localhost] [basePort=9000] [portCount=1] [seconds=40]
 */
public class TcpLoadClient {
    static final AtomicLong connected = new AtomicLong();
    static final AtomicLong errors = new AtomicLong();

    public static void main(String[] args) throws Exception {
        int n = Integer.parseInt(args[0]);
        String host = args.length > 1 ? args[1] : "localhost";
        int basePort = args.length > 2 ? Integer.parseInt(args[2]) : 9000;
        int ports = args.length > 3 ? Integer.parseInt(args[3]) : 1;
        int seconds = args.length > 4 ? Integer.parseInt(args[4]) : 40;
        long endAt = System.currentTimeMillis() + seconds * 1000L;

        Thread.ofVirtual().start(() -> {
            while (true) {
                try { Thread.sleep(2000); } catch (InterruptedException e) { return; }
                System.out.printf("client: connected=%d errors=%d%n", connected.get(), errors.get());
            }
        });

        try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < n; i++) {
                final int id = i;
                exec.submit(() -> run(host, basePort + id % ports, id, endAt));
                if (i % 200 == 199) Thread.sleep(20);   // ramp so the accept backlog is not overrun
            }
        }
        System.out.println("client done");
        System.exit(0);
    }

    static void run(String host, int port, int id, long endAt) {
        try (Socket s = new Socket(host, port); OutputStream out = s.getOutputStream()) {
            connected.incrementAndGet();
            Thread.sleep(ThreadLocalRandom.current().nextLong(1000));
            byte[] ping = ("ping " + id + "\n").getBytes(StandardCharsets.UTF_8);
            while (System.currentTimeMillis() < endAt) {
                out.write(ping);
                out.flush();
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            errors.incrementAndGet();
        } finally {
            connected.decrementAndGet();
        }
    }
}
