package com.gridweaver.audit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicLong;

/**
 * The same blocking thread-per-connection server in two flavours:
 *   platform : one OS thread per connection ("traditional")
 *   virtual  : one virtual thread per connection (Project Loom)
 * Everything else is identical, so any difference in threads / memory is the threading model.
 *
 * Usage: BlockingServer <platform|virtual> [basePort=9000] [portCount=1]
 * Listens on several ports because one client IP can only open ~28k connections to ONE destination
 * port (ephemeral port range); spreading across ports lets the client reach 50k+.
 *
 * Prints:  STATS,mode,openConnections,messages,platformThreads,heapMB,rssMB,threadCreateFailures
 */
public class BlockingServer {
    static final AtomicLong open = new AtomicLong();
    static final AtomicLong messages = new AtomicLong();
    static final AtomicLong failures = new AtomicLong();

    public static void main(String[] args) throws Exception {
        String mode = args.length > 0 ? args[0] : "virtual";
        int basePort = args.length > 1 ? Integer.parseInt(args[1]) : 9000;
        int ports = args.length > 2 ? Integer.parseInt(args[2]) : 1;
        boolean virtual = mode.equals("virtual");
        if (!virtual && !mode.equals("platform")) throw new IllegalArgumentException("mode = platform|virtual");

        for (int i = 0; i < ports; i++) {
            final int port = basePort + i;
            Thread.ofPlatform().name("acceptor-" + port).start(() -> acceptLoop(port, virtual));
        }
        System.out.printf("server up: mode=%s ports=%d-%d%n", mode, basePort, basePort + ports - 1);

        var threads = ManagementFactory.getThreadMXBean();
        var rt = Runtime.getRuntime();
        while (true) {
            Thread.sleep(2000);
            System.out.printf("STATS,%s,%d,%d,%d,%d,%d,%d%n", mode, open.get(), messages.get(),
                    threads.getThreadCount(),                               // platform threads only
                    (rt.totalMemory() - rt.freeMemory()) / 1_048_576, rssMb(), failures.get());
        }
    }

    static void acceptLoop(int port, boolean virtual) {
        try (ServerSocket server = new ServerSocket(port, 4096)) {
            while (true) {
                Socket socket = server.accept();
                Runnable task = () -> handle(socket);
                try {
                    if (virtual) Thread.startVirtualThread(task);
                    else new Thread(task).start();
                } catch (Throwable t) {          // typically OutOfMemoryError: unable to create native thread
                    failures.incrementAndGet();
                    try { socket.close(); } catch (IOException ignored) {}
                }
            }
        } catch (IOException e) {
            System.err.println("acceptor on " + port + " stopped: " + e);
        }
    }

    static void handle(Socket socket) {
        open.incrementAndGet();
        try (socket; var in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            while (in.readLine() != null) messages.incrementAndGet();    // blocking read
        } catch (IOException ignored) {
        } finally {
            open.decrementAndGet();
        }
    }

    static long rssMb() {
        try {
            for (String line : Files.readAllLines(Path.of("/proc/self/status"))) {
                if (line.startsWith("VmRSS:")) return Long.parseLong(line.replaceAll("\\D+", "")) / 1024;
            }
        } catch (Exception ignored) {}
        return -1;   // not Linux
    }
}
