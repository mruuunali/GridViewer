package com.gridweaver.protocol;

/** A frame that could not be processed, published to telemetry.dlq for inspection and replay. */
public record DeadLetter(String source, String reason, String payload, long ts) {
    public static final int MAX_PAYLOAD = 1024;

    public static DeadLetter of(String source, String reason, String payload) {
        String p = payload == null ? "" : payload.length() > MAX_PAYLOAD ? payload.substring(0, MAX_PAYLOAD) : payload;
        return new DeadLetter(source, reason, p, System.currentTimeMillis());
    }
}
