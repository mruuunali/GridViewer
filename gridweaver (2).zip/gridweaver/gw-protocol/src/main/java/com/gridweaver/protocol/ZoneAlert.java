package com.gridweaver.protocol;

/** Zone state change, published to grid.alerts (feeds the dashboard in Phase 4). */
public record ZoneAlert(
        String zoneId,
        String fromState,
        String toState,
        double baselineW,
        double generationW,
        double deficitW,
        double committedDischargeW,
        long ts
) {}
