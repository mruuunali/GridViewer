package com.gridweaver.protocol;

/**
 * Running totals for one zone, built from the LATEST value of every device in the zone.
 * add() / subtract() are exact inverses so they can back a Kafka Streams KTable aggregation.
 */
public record ZoneAggregate(
        String zoneId,
        double generationW,    // sum of solar output
        double consumptionW,   // sum of meter readings (load)
        double dischargeW,     // sum of batteries currently pushing power out
        double chargeW,        // sum of batteries currently absorbing power
        int solarCount,
        int batteryCount,
        int meterCount,
        long lastIngestAt      // receivedAt of the newest contributing message (latency probe)
) {
    public static ZoneAggregate empty() { return new ZoneAggregate(null, 0, 0, 0, 0, 0, 0, 0, 0); }

    public ZoneAggregate add(TelemetryMessage t) { return apply(t, +1); }

    public ZoneAggregate subtract(TelemetryMessage t) { return apply(t, -1); }

    private ZoneAggregate apply(TelemetryMessage t, int sign) {
        double gen = generationW, con = consumptionW, dis = dischargeW, chg = chargeW;
        int s = solarCount, b = batteryCount, m = meterCount;
        switch (t.type()) {
            case SOLAR -> { gen += sign * t.powerW(); s += sign; }
            case METER -> { con += sign * t.powerW(); m += sign; }
            case BATTERY -> {
                b += sign;
                if (t.powerW() > 0) dis += sign * t.powerW(); else chg += sign * -t.powerW();
            }
        }
        long ingest = sign > 0 ? Math.max(lastIngestAt, t.receivedAt()) : lastIngestAt;
        return new ZoneAggregate(zoneId != null ? zoneId : t.zoneId(),
                Math.max(0, gen), Math.max(0, con), Math.max(0, dis), Math.max(0, chg),
                Math.max(0, s), Math.max(0, b), Math.max(0, m), ingest);
    }
}
