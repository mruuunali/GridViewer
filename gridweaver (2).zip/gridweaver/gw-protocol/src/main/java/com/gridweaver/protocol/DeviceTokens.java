package com.gridweaver.protocol;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.Base64;

/**
 * Per-device bearer tokens: {@code <expiryEpochSec>.<base64url(HMAC-SHA256(secret, deviceId + "." + expiry))>}.
 * A token is bound to one deviceId, so a token stolen from device A cannot connect as device B, and it expires.
 * The secret never leaves the provisioning service and the ingestion nodes. Production: rotate the secret,
 * or move to per-device certificates (mTLS); see docs/PHASE5.md.
 */
public final class DeviceTokens {
    private static final String ALG = "HmacSHA256";

    private DeviceTokens() {}

    public static String sign(String secret, String deviceId, long expiryEpochSec) {
        if (secret == null || secret.isEmpty()) throw new IllegalArgumentException("secret must not be empty");
        return expiryEpochSec + "." + mac(secret, deviceId + "." + expiryEpochSec);
    }

    public static boolean verify(String secret, String deviceId, String token, long nowEpochSec) {
        if (secret == null || secret.isEmpty() || deviceId == null || token == null) return false;
        int dot = token.indexOf('.');
        if (dot <= 0 || dot == token.length() - 1) return false;
        long expiry;
        try {
            expiry = Long.parseLong(token.substring(0, dot));
        } catch (NumberFormatException e) {
            return false;
        }
        if (expiry < nowEpochSec) return false;
        byte[] expected = mac(secret, deviceId + "." + expiry).getBytes(StandardCharsets.UTF_8);
        byte[] given = token.substring(dot + 1).getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(expected, given);   // constant-time compare
    }

    private static String mac(String secret, String data) {
        try {
            Mac m = Mac.getInstance(ALG);
            m.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), ALG));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(m.doFinal(data.getBytes(StandardCharsets.UTF_8)));
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }
}
