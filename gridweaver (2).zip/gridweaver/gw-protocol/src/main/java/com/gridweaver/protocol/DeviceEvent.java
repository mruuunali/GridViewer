package com.gridweaver.protocol;

/** Audit/state-change record published to device.events. */
public record DeviceEvent(
        String deviceId,
        String zoneId,
        String fromState,
        String toState,
        String trigger,
        String reason,
        long ts
) {}
