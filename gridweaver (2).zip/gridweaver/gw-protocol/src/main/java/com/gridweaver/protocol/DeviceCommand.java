package com.gridweaver.protocol;

/** Downlink command from the state engine to a device (via Kafka -> ingestion node -> socket). */
public record DeviceCommand(
        String commandId,
        String deviceId,
        Action action,
        double powerW,
        String reason,
        long issuedAt
) {
    public enum Action { DISCHARGE, CHARGE, STOP }
}
