package com.gridweaver.protocol;

public enum DeviceType { SOLAR, BATTERY, METER }
