package com.gridweaver.protocol;

/**
 * Battery power one zone lends to a neighbour during a deficit. One record per (from, to) pair;
 * active=false means the loan ended. Published to grid.transfers and drawn as a flow line on the map.
 */
public record PowerTransfer(String fromZone, String toZone, double powerW, int batteries, boolean active, long ts) {}
