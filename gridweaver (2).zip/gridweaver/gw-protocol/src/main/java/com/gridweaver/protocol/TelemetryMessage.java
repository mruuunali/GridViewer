package com.gridweaver.protocol;

/**
 * One telemetry ping from a device.
 * MVP uses JSON; swap to Protobuf later without touching callers of this record.
 */
public record TelemetryMessage(
        String deviceId,
        String zoneId,
        DeviceType type,
        long seq,          // per-device sequence number (replay/loss detection)
        long ts,           // device timestamp, epoch millis
        double powerW,     // + generation / discharge, - charge / consumption
        double socPct,     // battery state of charge (0-100), NaN/0 for solar
        double tempC,
        long receivedAt    // set by ingestion, epoch millis
) {
    public TelemetryMessage withReceivedAt(long t) {
        return new TelemetryMessage(deviceId, zoneId, type, seq, ts, powerW, socPct, tempC, t);
    }

    public boolean isValid() {
        return deviceId != null && !deviceId.isBlank()
                && zoneId != null && !zoneId.isBlank()
                && type != null
                && tempC > -60 && tempC < 150
                && socPct >= 0 && socPct <= 100;
    }
}
