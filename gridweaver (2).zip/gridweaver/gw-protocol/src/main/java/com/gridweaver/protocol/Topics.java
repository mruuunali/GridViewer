package com.gridweaver.protocol;

public final class Topics {
    private Topics() {}
    public static final String TELEMETRY_RAW  = "telemetry.raw";
    public static final String ZONE_AGG       = "telemetry.zone-agg";
    public static final String DEVICE_EVENTS  = "device.events";
    public static final String DEVICE_STATE   = "device.state";
    public static final String DEVICE_COMMANDS = "device.commands";
    public static final String GRID_ALERTS    = "grid.alerts";
    public static final String TELEMETRY_DLQ = "telemetry.dlq";
    public static final String GRID_TRANSFERS = "grid.transfers";
}
