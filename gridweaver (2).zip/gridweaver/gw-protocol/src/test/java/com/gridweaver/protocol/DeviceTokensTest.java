package com.gridweaver.protocol;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DeviceTokensTest {
    private static final String SECRET = "test-secret";

    @Test
    void validTokenVerifies() {
        assertTrue(DeviceTokens.verify(SECRET, "dev-1", DeviceTokens.sign(SECRET, "dev-1", 2000), 1000));
    }

    @Test
    void tokenIsBoundToTheDevice() {
        assertFalse(DeviceTokens.verify(SECRET, "dev-2", DeviceTokens.sign(SECRET, "dev-1", 2000), 1000));
    }

    @Test
    void expiredWrongSecretAndGarbageAreRejected() {
        assertFalse(DeviceTokens.verify(SECRET, "dev-1", DeviceTokens.sign(SECRET, "dev-1", 500), 1000));
        assertFalse(DeviceTokens.verify("other", "dev-1", DeviceTokens.sign(SECRET, "dev-1", 2000), 1000));
        assertFalse(DeviceTokens.verify(SECRET, "dev-1", null, 1000));
        assertFalse(DeviceTokens.verify(SECRET, "dev-1", "", 1000));
        assertFalse(DeviceTokens.verify(SECRET, "dev-1", "abc", 1000));
        assertFalse(DeviceTokens.verify(SECRET, "dev-1", "2000.", 1000));
        assertFalse(DeviceTokens.verify("", "dev-1", DeviceTokens.sign(SECRET, "dev-1", 2000), 1000));   // empty secret never verifies
        assertThrows(IllegalArgumentException.class, () -> DeviceTokens.sign("", "dev-1", 2000));        // and cannot sign
    }

    @Test
    void extendingTheExpiryInvalidatesTheToken() {
        String t = DeviceTokens.sign(SECRET, "dev-1", 2000);
        String forged = "9999999999" + t.substring(t.indexOf('.'));
        assertFalse(DeviceTokens.verify(SECRET, "dev-1", forged, 1000));
    }
}
