package com.gridweaver.protocol;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ZoneAggregateTest {
    private static TelemetryMessage msg(DeviceType type, double power) {
        return new TelemetryMessage("d", "z1", type, 1, 1, power, 50, 25, 1000);
    }

    @Test
    void addThenSubtractReturnsToZero() {
        var solar = msg(DeviceType.SOLAR, 3000);
        var batt = msg(DeviceType.BATTERY, 2000);
        var meter = msg(DeviceType.METER, 1500);
        var agg = ZoneAggregate.empty().add(solar).add(batt).add(meter);
        assertEquals(3000, agg.generationW());
        assertEquals(2000, agg.dischargeW());
        assertEquals(1500, agg.consumptionW());
        agg = agg.subtract(solar).subtract(batt).subtract(meter);
        assertEquals(0, agg.generationW());
        assertEquals(0, agg.dischargeW());
        assertEquals(0, agg.consumptionW());
        assertEquals(0, agg.solarCount() + agg.batteryCount() + agg.meterCount());
    }

    @Test
    void updateReplacesOldContribution() {
        var old = msg(DeviceType.METER, 1500);
        var upd = msg(DeviceType.METER, 1800);
        var agg = ZoneAggregate.empty().add(old).subtract(old).add(upd);
        assertEquals(1800, agg.consumptionW());
        assertEquals(1, agg.meterCount());
    }
}
