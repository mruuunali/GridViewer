package com.gridweaver.gateway;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/** Every tick: take what changed, serialize ONCE, send the same string to every browser. */
@Component
public class Broadcaster {
    private static final Logger log = LoggerFactory.getLogger(Broadcaster.class);

    private final GridState state;
    private final ClientRegistry clients;
    private final ObjectMapper mapper;
    private final Counter pushes;

    public Broadcaster(GridState state, ClientRegistry clients, ObjectMapper mapper, MeterRegistry meters) {
        this.state = state;
        this.clients = clients;
        this.mapper = mapper;
        this.pushes = meters.counter("gridweaver.gateway.pushes");
    }

    @Scheduled(fixedRateString = "${gridweaver.gateway.push-interval-ms:200}")
    public void tick() {
        Messages.Delta delta = state.drain();      // always drain, so state can't pile up with no clients
        if (delta.isEmpty() || clients.isEmpty()) return;
        try {
            clients.broadcast(mapper.writeValueAsString(delta));
            pushes.increment();
        } catch (Exception e) {
            log.warn("broadcast failed: {}", e.toString());
        }
    }
}
