package com.gridweaver.gateway;

import com.gridweaver.gateway.Messages.*;
import com.gridweaver.protocol.DeviceEvent;
import com.gridweaver.protocol.PowerTransfer;
import com.gridweaver.protocol.ZoneAggregate;
import com.gridweaver.protocol.ZoneAlert;
import org.springframework.stereotype.Component;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * In-memory view of the grid, fed by Kafka listeners and drained by the broadcaster.
 * "Dirty" sets coalesce bursts: a zone updated 10 times between ticks is sent once, with its latest values.
 * Held in memory only for now; Phase 5 rebuilds it from Redis on restart.
 */
@Component
public class GridState {
    private static final int MAX_PENDING_LOG = 5_000;
    private static final int RECENT_LOG = 200;

    private final ConcurrentHashMap<String, ZoneAggregate> zoneAgg = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, String> zoneState = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, String> nodeState = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, String> nodeZone = new ConcurrentHashMap<>();
    private final Set<String> dirtyZones = ConcurrentHashMap.newKeySet();
    private final Set<String> dirtyNodes = ConcurrentHashMap.newKeySet();
    private final ConcurrentHashMap<String, TransferView> activeTransfers = new ConcurrentHashMap<>();   // key = from>to
    private final ConcurrentHashMap<String, TransferView> pendingTransfers = new ConcurrentHashMap<>();
    private final ConcurrentLinkedQueue<LogEntry> pendingLog = new ConcurrentLinkedQueue<>();
    private final AtomicInteger pendingLogSize = new AtomicInteger();
    private final Deque<LogEntry> recentLog = new ArrayDeque<>();

    public void onAggregate(ZoneAggregate a) {
        if (a.zoneId() == null) return;
        zoneAgg.put(a.zoneId(), a);
        dirtyZones.add(a.zoneId());
    }

    /** Startup rebuild from Redis (no log entry, no dirty flag: the first snapshot carries it). */
    public void seedZone(String zoneId, String state) { zoneState.put(zoneId, state); }

    public void seedNode(String deviceId, String state, String zone) {
        nodeState.put(deviceId, state);
        nodeZone.put(deviceId, zone);
    }

    public void onZoneAlert(ZoneAlert a) {
        zoneState.put(a.zoneId(), a.toState());
        dirtyZones.add(a.zoneId());
        log(new LogEntry(a.ts(), "ZONE", a.zoneId(), a.fromState(), a.toState(), "load/deficit",
                String.format("deficit %.0f W, generation %.0f W", a.deficitW(), a.generationW())));
    }

    public void onDeviceEvent(DeviceEvent e) {
        nodeState.put(e.deviceId(), e.toState());
        if (e.zoneId() != null) nodeZone.put(e.deviceId(), e.zoneId());
        dirtyNodes.add(e.deviceId());
        log(new LogEntry(e.ts(), "DEVICE", e.deviceId(), e.fromState(), e.toState(), e.trigger(), e.reason()));
    }

    public void onTransfer(PowerTransfer t) {
        String key = t.fromZone() + ">" + t.toZone();
        TransferView v = new TransferView(t.fromZone(), t.toZone(), t.powerW(), t.batteries(), t.active(), t.ts());
        TransferView prev = t.active() ? activeTransfers.put(key, v) : activeTransfers.remove(key);
        pendingTransfers.put(key, v);
        String from = prev == null ? "-" : "ACTIVE";
        String to = t.active() ? "ACTIVE" : "ENDED";
        log(new LogEntry(t.ts(), "TRANSFER", t.fromZone() + " -> " + t.toZone(), from, to, "NEIGHBOUR_LOAN",
                t.active() ? String.format("%d batteries, %.0f W", t.batteries(), t.powerW()) : "loan released"));
    }

    /** Everything that changed since the last call. */
    public Delta drain() {
        List<ZoneView> zones = new ArrayList<>();
        for (var it = dirtyZones.iterator(); it.hasNext(); ) {
            String id = it.next();
            it.remove();
            zones.add(zoneView(id));
        }
        List<NodeUpdate> nodes = new ArrayList<>();
        for (var it = dirtyNodes.iterator(); it.hasNext(); ) {
            String id = it.next();
            it.remove();
            nodes.add(new NodeUpdate(id, nodeState.get(id), nodeZone.get(id)));
        }
        List<LogEntry> log = new ArrayList<>();
        LogEntry e;
        while ((e = pendingLog.poll()) != null) {
            pendingLogSize.decrementAndGet();
            log.add(e);
        }
        List<TransferView> transfers = new ArrayList<>();
        for (String key : new ArrayList<>(pendingTransfers.keySet())) {
            TransferView v = pendingTransfers.remove(key);
            if (v != null) transfers.add(v);
        }
        return new Delta("delta", System.currentTimeMillis(), zones, nodes, log, transfers);
    }

    /** Full state for a newly connected browser. */
    public Delta snapshot() {
        List<ZoneView> zones = new ArrayList<>();
        for (String id : zoneAgg.keySet()) zones.add(zoneView(id));
        List<NodeUpdate> nodes = new ArrayList<>();
        nodeState.forEach((id, st) -> nodes.add(new NodeUpdate(id, st, nodeZone.get(id))));
        List<LogEntry> log;
        synchronized (recentLog) {
            log = new ArrayList<>(recentLog);
        }
        return new Delta("snapshot", System.currentTimeMillis(), zones, nodes, log, new ArrayList<>(activeTransfers.values()));
    }

    public List<ZoneView> currentZones() {
        List<ZoneView> list = new ArrayList<>();
        for (String id : zoneAgg.keySet()) list.add(zoneView(id));
        return list;
    }

    private ZoneView zoneView(String id) {
        ZoneAggregate a = zoneAgg.get(id);
        String state = zoneState.getOrDefault(id, "NORMAL");
        if (a == null) return new ZoneView(id, state, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        double ratio = a.meterCount() > 0 ? a.consumptionW() / Math.max(a.generationW(), 1.0) : 0;
        return new ZoneView(id, state, a.generationW(), a.consumptionW(), a.dischargeW(), a.chargeW(), ratio,
                a.solarCount(), a.batteryCount(), a.meterCount(), a.lastIngestAt());
    }

    private void log(LogEntry e) {
        pendingLog.add(e);
        if (pendingLogSize.incrementAndGet() > MAX_PENDING_LOG) {
            pendingLog.poll();
            pendingLogSize.decrementAndGet();
        }
        synchronized (recentLog) {   // tiny non-blocking critical section
            recentLog.addLast(e);
            if (recentLog.size() > RECENT_LOG) recentLog.removeFirst();
        }
    }
}
