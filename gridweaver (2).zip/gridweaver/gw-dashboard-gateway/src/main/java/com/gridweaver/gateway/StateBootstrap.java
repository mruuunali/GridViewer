package com.gridweaver.gateway;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * On startup, reload zone and battery states that the state engine persisted in Redis, so restarting the
 * gateway mid-storm shows EMERGENCY / DISCHARGING immediately instead of NORMAL / IDLE until the next transition.
 * Best effort: if Redis is unreachable the gateway starts empty and catches up from Kafka.
 */
@Component
public class StateBootstrap {
    private static final Logger log = LoggerFactory.getLogger(StateBootstrap.class);

    private final StringRedisTemplate redis;
    private final GridState state;

    public StateBootstrap(StringRedisTemplate redis, GridState state) {
        this.redis = redis;
        this.state = state;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void load() {
        try {
            int zones = 0, nodes = 0;
            for (Map.Entry<Object, Object> e : redis.opsForHash().entries("gw:zone-state").entrySet()) {
                state.seedZone((String) e.getKey(), (String) e.getValue());
                zones++;
            }
            for (Map.Entry<Object, Object> e : redis.opsForHash().entries("gw:battery-state").entrySet()) {
                String[] p = ((String) e.getValue()).split("\\|", 2);   // "zone|STATE"
                if (p.length == 2) { state.seedNode((String) e.getKey(), p[1], p[0]); nodes++; }
            }
            log.info("rebuilt gateway state from Redis: {} zones, {} batteries", zones, nodes);
        } catch (Exception e) {
            log.warn("could not rebuild from Redis ({}); starting empty", e.toString());
        }
    }
}
