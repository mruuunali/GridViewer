package com.gridweaver.gateway;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.ConcurrentWebSocketSessionDecorator;
import org.springframework.web.socket.handler.TextWebSocketHandler;

@Component
public class DashboardSocketHandler extends TextWebSocketHandler {
    private final ClientRegistry clients;
    private final GridState state;
    private final ObjectMapper mapper;

    public DashboardSocketHandler(ClientRegistry clients, GridState state, ObjectMapper mapper) {
        this.clients = clients;
        this.state = state;
        this.mapper = mapper;
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        // 2s send timeout, 512 KB buffer: a stuck browser is cut off instead of stalling everyone else.
        var safe = new ConcurrentWebSocketSessionDecorator(session, 2000, 512 * 1024,
                ConcurrentWebSocketSessionDecorator.OverflowStrategy.DROP);
        clients.add(session.getId(), safe);
        safe.sendMessage(new TextMessage(mapper.writeValueAsString(state.snapshot())));
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) {
        // Reserved: viewport subscriptions ({"bbox": [...], "zoom": n}) arrive here in a later phase.
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        clients.remove(session.getId());
    }
}
