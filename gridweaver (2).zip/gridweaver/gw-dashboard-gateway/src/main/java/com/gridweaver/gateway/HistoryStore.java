package com.gridweaver.gateway;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayDeque;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Last 10 minutes of each zone at 1 sample/second, in memory. Feeds the zone detail chart.
 * Long-term history and storm replay come from TimescaleDB in a later phase.
 */
@Component
public class HistoryStore {
    public record Sample(long ts, String state, double generationW, double consumptionW,
                         double dischargeW, double loadRatio) {}

    private static final int CAPACITY = 600;

    private final GridState state;
    private final ConcurrentHashMap<String, ArrayDeque<Sample>> history = new ConcurrentHashMap<>();

    public HistoryStore(GridState state) { this.state = state; }

    @Scheduled(fixedRate = 1000)
    public void sample() {
        long now = System.currentTimeMillis();
        for (Messages.ZoneView z : state.currentZones()) {
            ArrayDeque<Sample> dq = history.computeIfAbsent(z.id(), k -> new ArrayDeque<>());
            synchronized (dq) {   // tiny non-blocking critical section
                dq.addLast(new Sample(now, z.state(), z.generationW(), z.consumptionW(), z.dischargeW(), z.loadRatio()));
                if (dq.size() > CAPACITY) dq.removeFirst();
            }
        }
    }

    public List<Sample> last(String zoneId, int seconds) {
        ArrayDeque<Sample> dq = history.get(zoneId);
        if (dq == null) return List.of();
        long cutoff = System.currentTimeMillis() - seconds * 1000L;
        synchronized (dq) {
            return dq.stream().filter(s -> s.ts() >= cutoff).toList();
        }
    }
}
