package com.gridweaver.gateway;

import java.util.List;

/** JSON shapes pushed to the browser. Keep in sync with gw-ui/src/types.ts. */
public final class Messages {
    private Messages() {}

    public record ZoneView(String id, String state, double generationW, double consumptionW, double dischargeW,
                           double chargeW, double loadRatio, int solar, int battery, int meter, long lastIngestAt) {}

    public record NodeUpdate(String id, String state, String zone) {}

    /** One row of the event log: a battery transition (DEVICE) or a zone transition (ZONE). */
    public record LogEntry(long ts, String kind, String subject, String from, String to, String trigger, String reason) {}

    /** One neighbour loan. active=false tells the UI to remove the flow line. */
    public record TransferView(String from, String to, double powerW, int batteries, boolean active, long ts) {}

    /** type = "snapshot" (full state, sent on connect) or "delta" (only what changed since the last tick). */
    public record Delta(String type, long ts, List<ZoneView> zones, List<NodeUpdate> nodes, List<LogEntry> log,
                        List<TransferView> transfers) {
        public boolean isEmpty() { return zones.isEmpty() && nodes.isEmpty() && log.isEmpty() && transfers.isEmpty(); }
    }
}
