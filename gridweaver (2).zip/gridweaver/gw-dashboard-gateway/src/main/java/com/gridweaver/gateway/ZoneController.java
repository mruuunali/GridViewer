package com.gridweaver.gateway;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "${gridweaver.gateway.allowed-origins}")
@RequestMapping("/api")
public class ZoneController {
    private final GridState state;
    private final HistoryStore history;

    public ZoneController(GridState state, HistoryStore history) {
        this.state = state;
        this.history = history;
    }

    @GetMapping("/zones")
    public List<Messages.ZoneView> zones() { return state.currentZones(); }

    /** GET /api/zones/zone-3/history?seconds=120 */
    @GetMapping("/zones/{id}/history")
    public List<HistoryStore.Sample> history(@PathVariable String id,
                                             @RequestParam(defaultValue = "120") int seconds) {
        return history.last(id, Math.min(Math.max(seconds, 1), 600));
    }
}
