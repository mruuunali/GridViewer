package com.gridweaver.gateway;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gridweaver.protocol.DeviceEvent;
import com.gridweaver.protocol.PowerTransfer;
import com.gridweaver.protocol.Topics;
import com.gridweaver.protocol.ZoneAggregate;
import com.gridweaver.protocol.ZoneAlert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Each gateway instance uses a fresh random consumer group, so every instance sees every message
 * (fan-out to its own browsers) and starts from "latest".
 */
@Component
public class KafkaFeeds {
    private static final Logger log = LoggerFactory.getLogger(KafkaFeeds.class);
    private static final String RANDOM_GROUP = "#{T(java.util.UUID).randomUUID().toString()}";

    private final ObjectMapper mapper;
    private final GridState state;

    public KafkaFeeds(ObjectMapper mapper, GridState state) {
        this.mapper = mapper;
        this.state = state;
    }

    @KafkaListener(topics = Topics.ZONE_AGG, groupId = RANDOM_GROUP)
    public void zoneAgg(String json) {
        try { state.onAggregate(mapper.readValue(json, ZoneAggregate.class)); }
        catch (Exception e) { log.debug("bad zone-agg: {}", e.toString()); }
    }

    @KafkaListener(topics = Topics.GRID_ALERTS, groupId = RANDOM_GROUP)
    public void alerts(String json) {
        try { state.onZoneAlert(mapper.readValue(json, ZoneAlert.class)); }
        catch (Exception e) { log.debug("bad alert: {}", e.toString()); }
    }

    @KafkaListener(topics = Topics.DEVICE_EVENTS, groupId = RANDOM_GROUP, concurrency = "2")
    public void deviceEvents(String json) {
        try { state.onDeviceEvent(mapper.readValue(json, DeviceEvent.class)); }
        catch (Exception e) { log.debug("bad device event: {}", e.toString()); }
    }

    @KafkaListener(topics = Topics.GRID_TRANSFERS, groupId = RANDOM_GROUP)
    public void transfers(String json) {
        try { state.onTransfer(mapper.readValue(json, PowerTransfer.class)); }
        catch (Exception e) { log.debug("bad transfer: {}", e.toString()); }
    }
}
