package com.gridweaver.gateway;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

import java.util.concurrent.ConcurrentHashMap;

@Component
public class ClientRegistry {
    private final ConcurrentHashMap<String, WebSocketSession> sessions = new ConcurrentHashMap<>();

    public ClientRegistry(MeterRegistry meters) {
        Gauge.builder("gridweaver.gateway.clients", sessions, ConcurrentHashMap::size).register(meters);
    }

    public void add(String id, WebSocketSession s) { sessions.put(id, s); }
    public void remove(String id) { sessions.remove(id); }
    public boolean isEmpty() { return sessions.isEmpty(); }

    /** Sessions are ConcurrentWebSocketSessionDecorators: thread-safe, bounded buffer, slow clients dropped. */
    public void broadcast(String json) {
        TextMessage msg = new TextMessage(json);
        sessions.forEach((id, s) -> {
            try {
                if (s.isOpen()) s.sendMessage(msg); else sessions.remove(id);
            } catch (Exception e) {
                sessions.remove(id);
            }
        });
    }
}
