package com.gridweaver.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@SpringBootApplication
@EnableScheduling
public class GatewayApplication {
    public static void main(String[] args) { SpringApplication.run(GatewayApplication.class, args); }

    @Configuration
    @EnableWebSocket
    static class WsConfig implements WebSocketConfigurer {
        private final DashboardSocketHandler handler;
        private final String[] origins;

        WsConfig(DashboardSocketHandler handler,
                 @org.springframework.beans.factory.annotation.Value("${gridweaver.gateway.allowed-origins}") String origins) {
            this.handler = handler;
            this.origins = origins.split("\\s*,\\s*");
        }

        @Override
        public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
            registry.addHandler(handler, "/ws/dashboard").setAllowedOrigins(origins);
        }
    }
}
