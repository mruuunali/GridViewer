# GridWeaver (Phases 1-3: ingestion, battery state engine, zone aggregation + automatic dispatch)

## Prerequisites
JDK 21, Maven 3.9+, Docker.

## Run
```bash
# 1. infra
docker compose -f deploy/docker-compose.yml up -d

# 2. build
mvn clean install -DskipTests

# 3. ingestion service (virtual threads enabled)
mvn -pl gw-ingestion spring-boot:run
#   add -Djdk.tracePinnedThreads=full via JAVA_TOOL_OPTIONS to detect pinning

# 4. simulator: 5000 devices, storm at 20s, run 90s
mvn -pl gw-simulator exec:java -Dexec.args="5000 ws://localhost:8080/ws/device 20 90"

# 5. watch messages arrive
docker exec -it gw-kafka /opt/kafka/bin/kafka-console-consumer.sh \
  --bootstrap-server localhost:9092 --topic telemetry.raw --from-beginning --max-messages 5

# metrics
curl localhost:8080/actuator/prometheus | grep gridweaver
```

## Final review (see docs/FINAL_REVIEW.md)
Demo run-sheet, the numbers to collect for the slide deck, fallbacks, and likely questions.

## Phase 5, part 1 (see docs/PHASE5.md)
Device auth (HMAC bearer tokens, off by default), replay protection, tombstones for disconnected devices, gateway state rebuild from Redis.
```bash
export GW_DEVICE_SECRET="$(openssl rand -base64 32)"
mvn -pl gw-ingestion spring-boot:run -Dspring-boot.run.arguments=--gridweaver.security.auth-enabled=true
mvn -pl gw-simulator exec:java -Dexec.args="500 ws://localhost:8080/ws/device 30 150 60 0 15"   # signs tokens from GW_DEVICE_SECRET
```

## Week 4 (see docs/WEEK4.md)
```bash
mvn -pl gw-simulator exec:java -Dexec.args="500 ws://localhost:8080/ws/device 30 150 60 0 15"   # storm hits zones 0-14 only
docker exec -it gw-kafka /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic grid.transfers
```
UI: animated loan lines between zones, Event log (filter / pause / CSV export).

## Week 3 (see docs/WEEK3.md)
```bash
scripts/kafka-lag.sh watch      # consumer lag + dead-letter count
scripts/dlq-peek.sh 5           # inspect rejected frames
mvn -pl gw-simulator exec:java -Dexec.args="500 ws://localhost:8080/ws/device 30 150 60 2"   # 2% bad frames
```
UI: heatmap toggle (Consumption / Generation / Net balance) and click-a-zone detail.

## Week 2 (see docs/WEEK2.md)
```bash
# add the gateway + UI to the Phase 1-3 services
mvn -pl gw-dashboard-gateway spring-boot:run     # port 8090
cd gw-ui && npm install && npm run dev           # http://localhost:5173
mvn -pl gw-simulator exec:java -Dexec.args="500 ws://localhost:8080/ws/device 30 150 60"
scripts/audit.sh                                 # platform vs virtual thread audit
cd gw-ui && npm run mock                         # UI-only demo, no backend
```

## Week 1 (see docs/WEEK1.md)
```bash
scripts/week1-loadtest.sh 10000     # backend baseline: 10k connections + metrics CSV
cd gw-ui && npm install && npm run dev   # map with 500 static mock nodes
```

## Phase 2: state engine demo
```bash
# terminal A: ingestion (8080)      mvn -pl gw-ingestion spring-boot:run
# terminal B: state engine (8081)   mvn -pl gw-state-engine spring-boot:run
# terminal C: simulator             mvn -pl gw-simulator exec:java -Dexec.args="1000 ws://localhost:8080/ws/device 20 120"

# after ~10s, batteries are registered in Redis. Trigger a deficit in zone-3:
curl -X POST "localhost:8081/api/zones/zone-3/dispatch?event=GRID_DEFICIT&limit=50"
# -> {"candidates":4,"selected":4,"transitioned":4,"tookMs":..}

curl localhost:8081/api/devices/dev-3                       # state should be DISCHARGING
docker exec -it gw-kafka /opt/kafka/bin/kafka-console-consumer.sh \
  --bootstrap-server localhost:9092 --topic device.events --from-beginning
# simulator output shows commands_rx increasing; SoC drains 0.5%/s and SOC_LOW returns the battery to IDLE.
```
The manual dispatch endpoint is temporary: in Phase 3 the zone state machine calls DispatchService
automatically when zone aggregates cross the deficit threshold.

## Phase 3: the storm, end to end
```bash
# terminals: ingestion (8080), state engine (8081), stream processor (8082)
mvn -pl gw-ingestion spring-boot:run
mvn -pl gw-state-engine spring-boot:run
mvn -pl gw-stream-processor spring-boot:run

# simulator: 1000 devices, storm hits at 30s and lasts 60s, total run 150s
mvn -pl gw-simulator exec:java -Dexec.args="1000 ws://localhost:8080/ws/device 30 150 60"

# watch zones flip NORMAL -> EMERGENCY -> RECOVERING -> NORMAL, no manual dispatch needed
watch -n1 'curl -s localhost:8081/api/zones | python3 -m json.tool | head -40'

# alerts stream
docker exec -it gw-kafka /opt/kafka/bin/kafka-console-consumer.sh \
  --bootstrap-server localhost:9092 --topic grid.alerts

# the sub-second claim: ingest -> decision latency (approximate)
curl -s localhost:8081/actuator/prometheus | grep gridweaver_zone_ingest_to_decision
```
Expected: within ~1s of the storm, zones go EMERGENCY, batteries switch to DISCHARGING, the simulator's
commands_rx jumps. When the storm ends, zones go RECOVERING (batteries released) then NORMAL after 30s.
Note the simulated zones have few batteries (4 per zone at 1000 devices), so the deficit is not fully
covered; that is realistic and is what neighbor-zone dispatch (later) is for.

## Scaling the test to 50k-100k
- One client IP can open ~64k connections to one server IP:port. Use multiple simulator
  processes/machines or add loopback aliases.
- Raise limits: `ulimit -n 200000` on both sides, `net.core.somaxconn`, `net.ipv4.ip_local_port_range`.
- Tomcat `max-connections` is already set to 200000 in application.yml.

## Next phases
2. gw-state-engine (Spring State Machine + Redis rehydration)
3. gw-stream-processor (Kafka Streams zone windows) + zone state machine + dispatch
4. gw-dashboard-gateway + gw-ui (React + Leaflet)
