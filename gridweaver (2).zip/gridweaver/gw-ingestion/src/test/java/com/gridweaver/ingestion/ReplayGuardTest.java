package com.gridweaver.ingestion;

import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicLong;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ReplayGuardTest {
    @Test
    void acceptsIncreasingAndRejectsReplayedOrOldSequenceNumbers() {
        AtomicLong last = ReplayGuard.newSession();
        assertTrue(ReplayGuard.accept(last, 0));
        assertTrue(ReplayGuard.accept(last, 1));
        assertFalse(ReplayGuard.accept(last, 1));   // duplicate
        assertFalse(ReplayGuard.accept(last, 0));   // replayed old frame
        assertTrue(ReplayGuard.accept(last, 5));    // gaps are fine (lost frames)
        assertFalse(ReplayGuard.accept(last, 4));
    }
}
