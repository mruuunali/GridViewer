package com.gridweaver.ingestion;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gridweaver.protocol.TelemetryMessage;
import com.gridweaver.protocol.Topics;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class TelemetryPublisher {
    private final KafkaTemplate<String, String> kafka;
    private final ObjectMapper mapper;
    private final Counter published;
    private final Counter failed;

    public TelemetryPublisher(KafkaTemplate<String, String> kafka, ObjectMapper mapper, MeterRegistry meters) {
        this.kafka = kafka;
        this.mapper = mapper;
        this.published = meters.counter("gridweaver.telemetry.published");
        this.failed = meters.counter("gridweaver.telemetry.publish.failed");
    }

    /**
     * A null-value record on telemetry.raw deletes the device from the stream processor's "latest reading"
     * table, so a disconnected device stops counting toward its zone's totals.
     */
    public void tombstone(String deviceId) {
        kafka.send(Topics.TELEMETRY_RAW, deviceId, (String) null);
    }

    /** Key = deviceId, so all events of one device land on one partition, in order. */
    public void publish(TelemetryMessage msg) throws JsonProcessingException {
        String json = mapper.writeValueAsString(msg);
        kafka.send(Topics.TELEMETRY_RAW, msg.deviceId(), json).whenComplete((r, ex) -> {
            if (ex != null) failed.increment(); else published.increment();
        });
    }
}
