package com.gridweaver.ingestion;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gridweaver.protocol.TelemetryMessage;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.concurrent.ConcurrentHashMap;

@Component
public class DeviceSocketHandler extends TextWebSocketHandler {
    private static final Logger log = LoggerFactory.getLogger(DeviceSocketHandler.class);
    private static final String DEVICE_ID = "deviceId";
    static final String SEND_LOCK = "sendLock";
    static final String LAST_SEQ = "lastSeq";

    private final SessionRegistry registry;
    private final TelemetryPublisher publisher;
    private final ObjectMapper mapper;
    private final DeadLetterPublisher dlq;
    private final int maxPerSecond;
    private final Counter invalid;
    private final Counter rateLimited;
    private final Counter replayed;

    /** deviceId -> {windowStartSecond, count}. Simple fixed-window limiter; replace with token bucket later. */
    private final ConcurrentHashMap<String, long[]> windows = new ConcurrentHashMap<>();

    public DeviceSocketHandler(SessionRegistry registry, TelemetryPublisher publisher, ObjectMapper mapper,
                               DeadLetterPublisher dlq, MeterRegistry meters,
                               @Value("${gridweaver.ingestion.max-messages-per-second-per-device}") int maxPerSecond) {
        this.registry = registry;
        this.publisher = publisher;
        this.mapper = mapper;
        this.dlq = dlq;
        this.maxPerSecond = maxPerSecond;
        this.invalid = meters.counter("gridweaver.telemetry.invalid");
        this.rateLimited = meters.counter("gridweaver.telemetry.ratelimited");
        this.replayed = meters.counter("gridweaver.telemetry.replayed");
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        String deviceId = UriComponentsBuilder.fromUri(session.getUri()).build().getQueryParams().getFirst(DEVICE_ID);
        if (deviceId == null || deviceId.isBlank()) {
            session.close(CloseStatus.POLICY_VIOLATION.withReason("deviceId required"));
            return;
        }
        // TODO Phase 5: authenticate (JWT / mTLS) before registering
        session.getAttributes().put(DEVICE_ID, deviceId);
        session.getAttributes().put(LAST_SEQ, ReplayGuard.newSession());
        session.getAttributes().put(SEND_LOCK, new java.util.concurrent.locks.ReentrantLock());
        registry.register(deviceId, session);
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        String deviceId = (String) session.getAttributes().get(DEVICE_ID);
        if (deviceId == null) return;

        if (!allow(deviceId)) { rateLimited.increment(); return; }

        TelemetryMessage msg;
        try {
            msg = mapper.readValue(message.getPayload(), TelemetryMessage.class);
        } catch (Exception e) {
            invalid.increment();
            dlq.send(deviceId, "parse error: " + e.getClass().getSimpleName(), message.getPayload());
            return;
        }
        // A device may only speak for itself.
        if (!msg.isValid() || !deviceId.equals(msg.deviceId())) {
            invalid.increment();
            dlq.send(deviceId, msg.isValid() ? "deviceId does not match connection" : "validation failed", message.getPayload());
            return;
        }

        java.util.concurrent.atomic.AtomicLong lastSeq = (java.util.concurrent.atomic.AtomicLong) session.getAttributes().get(LAST_SEQ);
        if (lastSeq != null && !ReplayGuard.accept(lastSeq, msg.seq())) { replayed.increment(); return; }

        publisher.publish(msg.withReceivedAt(System.currentTimeMillis()));
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        String deviceId = (String) session.getAttributes().get(DEVICE_ID);
        if (deviceId != null) {
            // Only the session that was actually registered tombstones; a stale socket replaced by a reconnect must not
            // delete the new connection's data.
            if (registry.unregister(deviceId, session)) publisher.tombstone(deviceId);
            windows.remove(deviceId);
        }
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable ex) {
        log.debug("transport error: {}", ex.toString());
    }

    private boolean allow(String deviceId) {
        long nowSec = System.currentTimeMillis() / 1000;
        long[] w = windows.computeIfAbsent(deviceId, k -> new long[]{nowSec, 0});
        synchronized (w) { // tiny, non-blocking critical section: safe with virtual threads
            if (w[0] != nowSec) { w[0] = nowSec; w[1] = 0; }
            return ++w[1] <= maxPerSecond;
        }
    }
}
