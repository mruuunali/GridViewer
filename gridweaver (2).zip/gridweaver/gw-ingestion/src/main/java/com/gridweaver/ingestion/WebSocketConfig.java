package com.gridweaver.ingestion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;
import org.springframework.web.socket.server.standard.ServletServerContainerFactoryBean;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {
    private final DeviceSocketHandler handler;
    private final DeviceAuthInterceptor auth;

    public WebSocketConfig(DeviceSocketHandler handler, DeviceAuthInterceptor auth) {
        this.handler = handler;
        this.auth = auth;
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        // Devices are not browsers, so Origin checks add nothing here; the token is the control.
        registry.addHandler(handler, "/ws/device").addInterceptors(auth).setAllowedOrigins("*");
    }

    @Bean
    ServletServerContainerFactoryBean wsContainer() {
        var c = new ServletServerContainerFactoryBean();
        c.setMaxTextMessageBufferSize(8 * 1024);   // telemetry frames are tiny
        c.setMaxSessionIdleTimeout(60_000L);        // idle devices get dropped
        return c;
    }
}
