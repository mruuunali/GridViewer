package com.gridweaver.ingestion;

import com.gridweaver.protocol.Topics;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.config.TopicConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.config.TopicBuilder;

@SpringBootApplication
public class IngestionApplication {
    public static void main(String[] args) {
        SpringApplication.run(IngestionApplication.class, args);
    }

    /**
     * telemetry.raw: high partition count for parallelism, SHORT retention (it is a buffer, not an archive;
     * history lives in TimescaleDB later). 12 partitions suits one dev machine; use 48-96 in production.
     * NOTE: Kafka can raise a topic's partition count but never lower it. Pick a number you can live with.
     */
    @Bean
    NewTopic telemetryRaw(@Value("${gridweaver.kafka.telemetry-partitions:12}") int partitions) {
        return TopicBuilder.name(Topics.TELEMETRY_RAW).partitions(partitions).replicas(1)
                .config(TopicConfig.RETENTION_MS_CONFIG, String.valueOf(24 * 3600 * 1000L))   // 1 day
                .config(TopicConfig.SEGMENT_MS_CONFIG, String.valueOf(3600 * 1000L))          // roll hourly so retention bites
                .build();
    }

    /** Malformed frames from every component. Low volume, kept a week for debugging and replay. */
    @Bean
    NewTopic telemetryDlq() {
        return TopicBuilder.name(Topics.TELEMETRY_DLQ).partitions(3).replicas(1)
                .config(TopicConfig.RETENTION_MS_CONFIG, String.valueOf(7 * 24 * 3600 * 1000L))
                .build();
    }
}
