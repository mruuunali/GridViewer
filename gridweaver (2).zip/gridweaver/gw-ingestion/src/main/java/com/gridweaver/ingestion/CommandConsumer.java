package com.gridweaver.ingestion;

import com.gridweaver.protocol.Topics;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

import java.io.IOException;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Downlink. Every ingestion node reads ALL commands (unique consumer group per node) and forwards
 * only those for devices connected here. Simple and correct for a few nodes; at larger scale switch
 * to per-node topics using the Redis deviceId -> nodeId registry.
 */
@Component
public class CommandConsumer {
    private final SessionRegistry registry;
    private final Counter delivered;
    private final Counter notHere;

    public CommandConsumer(SessionRegistry registry, MeterRegistry meters) {
        this.registry = registry;
        this.delivered = meters.counter("gridweaver.commands.delivered");
        this.notHere = meters.counter("gridweaver.commands.not_local");
    }

    @KafkaListener(topics = Topics.DEVICE_COMMANDS, groupId = "#{T(java.util.UUID).randomUUID().toString()}")
    public void onCommand(ConsumerRecord<String, String> rec) {
        var session = registry.find(rec.key());
        if (session.isEmpty()) { notHere.increment(); return; }
        send(session.get(), rec.value());
    }

    private void send(WebSocketSession session, String json) {
        ReentrantLock lock = (ReentrantLock) session.getAttributes().get(DeviceSocketHandler.SEND_LOCK);
        if (lock == null) return;
        lock.lock();   // WebSocket sessions allow one sender at a time; ReentrantLock is virtual-thread friendly
        try {
            if (session.isOpen()) {
                session.sendMessage(new TextMessage(json));
                delivered.increment();
            }
        } catch (IOException ignored) {
        } finally {
            lock.unlock();
        }
    }
}
