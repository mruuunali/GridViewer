package com.gridweaver.ingestion;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketSession;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/** deviceId -> live session on THIS node. (Redis mirror deviceId -> nodeId comes in Phase 2.) */
@Component
public class SessionRegistry {
    private final ConcurrentHashMap<String, WebSocketSession> sessions = new ConcurrentHashMap<>();

    public SessionRegistry(MeterRegistry meters) {
        Gauge.builder("gridweaver.connections.active", sessions, ConcurrentHashMap::size).register(meters);
    }

    public void register(String deviceId, WebSocketSession s) {
        WebSocketSession old = sessions.put(deviceId, s);
        if (old != null && old.isOpen()) {
            try { old.close(); } catch (Exception ignored) {}   // device reconnected: drop stale socket
        }
    }

    /** @return true if this session was the one registered (false if the device already reconnected elsewhere). */
    public boolean unregister(String deviceId, WebSocketSession s) {
        return sessions.remove(deviceId, s);
    }

    public Optional<WebSocketSession> find(String deviceId) {
        return Optional.ofNullable(sessions.get(deviceId));
    }

    public int size() { return sessions.size(); }
}
