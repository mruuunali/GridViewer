package com.gridweaver.ingestion;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Per-connection replay protection: a frame is accepted only if its sequence number is strictly greater
 * than the last accepted one on this connection. A captured frame re-sent later (or duplicated) is dropped.
 * Scope: one WebSocket session. Cross-session replay needs the last seq kept in Redis (docs/PHASE5.md).
 */
final class ReplayGuard {
    private ReplayGuard() {}

    static AtomicLong newSession() { return new AtomicLong(-1); }

    static boolean accept(AtomicLong lastSeq, long seq) {
        while (true) {
            long prev = lastSeq.get();
            if (seq <= prev) return false;
            if (lastSeq.compareAndSet(prev, seq)) return true;
        }
    }
}
