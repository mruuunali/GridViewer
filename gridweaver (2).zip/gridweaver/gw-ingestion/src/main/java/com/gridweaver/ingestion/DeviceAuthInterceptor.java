package com.gridweaver.ingestion;

import com.gridweaver.protocol.DeviceTokens;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;

/**
 * Rejects the WebSocket upgrade (HTTP 401) unless the device presents a valid, unexpired token for the
 * deviceId it claims. Token travels in the Authorization header, never the URL, so it stays out of access logs.
 * Disabled by default so local demos keep working; enable it for anything beyond your laptop.
 */
@Component
public class DeviceAuthInterceptor implements HandshakeInterceptor {
    private static final Logger log = LoggerFactory.getLogger(DeviceAuthInterceptor.class);

    private final boolean enabled;
    private final String secret;
    private final Counter rejected;

    public DeviceAuthInterceptor(@Value("${gridweaver.security.auth-enabled:false}") boolean enabled,
                                 @Value("${gridweaver.security.device-secret:}") String secret,
                                 MeterRegistry meters) {
        this.enabled = enabled;
        this.secret = secret;
        this.rejected = meters.counter("gridweaver.auth.rejected");
    }

    @PostConstruct
    void check() {
        if (enabled && (secret == null || secret.length() < 16)) {
            throw new IllegalStateException("gridweaver.security.device-secret must be at least 16 characters when auth is enabled");
        }
        if (!enabled) log.warn("DEVICE AUTHENTICATION IS DISABLED (gridweaver.security.auth-enabled=false). Any client can connect as any device.");
    }

    @Override
    public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response,
                                   WebSocketHandler handler, Map<String, Object> attributes) {
        if (!enabled) return true;
        String deviceId = UriComponentsBuilder.fromUri(request.getURI()).build().getQueryParams().getFirst("deviceId");
        String header = request.getHeaders().getFirst("Authorization");
        String token = header != null && header.startsWith("Bearer ") ? header.substring(7) : null;
        if (deviceId == null || !DeviceTokens.verify(secret, deviceId, token, System.currentTimeMillis() / 1000)) {
            rejected.increment();
            response.setStatusCode(HttpStatus.UNAUTHORIZED);
            return false;
        }
        return true;
    }

    @Override
    public void afterHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler handler, Exception ex) {}
}
