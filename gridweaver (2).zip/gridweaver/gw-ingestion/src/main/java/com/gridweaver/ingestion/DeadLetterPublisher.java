package com.gridweaver.ingestion;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gridweaver.protocol.DeadLetter;
import com.gridweaver.protocol.Topics;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

/** Sends frames we cannot use to telemetry.dlq instead of silently dropping them. */
@Component
public class DeadLetterPublisher {
    private final KafkaTemplate<String, String> kafka;
    private final ObjectMapper mapper;
    private final Counter sent;

    public DeadLetterPublisher(KafkaTemplate<String, String> kafka, ObjectMapper mapper, MeterRegistry meters) {
        this.kafka = kafka;
        this.mapper = mapper;
        this.sent = meters.counter("gridweaver.telemetry.dlq");
    }

    public void send(String deviceId, String reason, String payload) {
        try {
            kafka.send(Topics.TELEMETRY_DLQ, deviceId,
                    mapper.writeValueAsString(DeadLetter.of("ingestion", reason, payload)));
            sent.increment();
        } catch (JsonProcessingException ignored) {
            // nothing sensible left to do with a frame we can't even describe
        }
    }
}
