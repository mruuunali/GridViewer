package com.gridweaver.simulator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gridweaver.protocol.DeviceTokens;
import com.gridweaver.protocol.DeviceType;
import com.gridweaver.protocol.TelemetryMessage;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Load generator: one virtual thread per simulated device.
 *
 * Usage: Simulator [devices=1000] [url=ws://localhost:8080/ws/device] [stormAfterSec=30] [durationSec=120] [stormLengthSec=60] [badFramePct=0] [stormZones=50]
 *
 * Per zone of 10 devices: 2 BATTERY, 2 METER (load), 6 SOLAR. Zones are idx % 50, so each
 * zone gets a mix. At stormAfterSec every SOLAR output collapses to ~10%. Batteries obey commands
 * (DISCHARGE / CHARGE / STOP) received from the state engine and report the resulting power and SoC.
 */
public class Simulator {
    static final ObjectMapper MAPPER = new ObjectMapper();
    static final AtomicLong sent = new AtomicLong();
    static final AtomicLong connected = new AtomicLong();
    static final AtomicLong errors = new AtomicLong();
    static final AtomicLong commands = new AtomicLong();
    static volatile int stormZones = 50;      // storm hits zones 0..stormZones-1 only (others stay sunny and can lend)
    static volatile double badFramePct = 0;   // % of messages replaced by garbage, to exercise the dead-letter topic

    public static void main(String[] args) throws Exception {
        int devices = args.length > 0 ? Integer.parseInt(args[0]) : 1000;
        String url = args.length > 1 ? args[1] : "ws://localhost:8080/ws/device";
        int stormAfterSec = args.length > 2 ? Integer.parseInt(args[2]) : 30;
        int durationSec = args.length > 3 ? Integer.parseInt(args[3]) : 120;
        int stormLengthSec = args.length > 4 ? Integer.parseInt(args[4]) : 60;

        badFramePct = args.length > 5 ? Double.parseDouble(args[5]) : 0;
        stormZones = args.length > 6 ? Integer.parseInt(args[6]) : 50;
        long start = System.currentTimeMillis();
        long stormAt = start + stormAfterSec * 1000L;
        long endAt = start + durationSec * 1000L;
        long stormEnd = stormAt + stormLengthSec * 1000L;

        HttpClient client = HttpClient.newHttpClient();

        Thread reporter = Thread.ofVirtual().unstarted(() -> {
            long last = 0;
            while (!Thread.currentThread().isInterrupted()) {
                try { Thread.sleep(2000); } catch (InterruptedException e) { return; }
                long s = sent.get();
                System.out.printf("connected=%d  sent=%d  rate=%d msg/s  commands_rx=%d  errors=%d  %s%n",
                        connected.get(), s, (s - last) / 2, commands.get(), errors.get(),
                        System.currentTimeMillis() >= stormAt && System.currentTimeMillis() < stormEnd ? "[STORM]" : "");
                last = s;
            }
        });
        reporter.start();

        try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < devices; i++) {
                final int idx = i;
                exec.submit(() -> runDevice(client, url, idx, stormAt, stormEnd, endAt));
                if (i % 100 == 99) Thread.sleep(50);   // ramp connections, avoid a SYN storm
            }
        }
        reporter.interrupt();
        System.out.println("done.");
    }

    static void runDevice(HttpClient client, String url, int idx, long stormAt, long stormEnd, long endAt) {
        String deviceId = "dev-" + idx;
        String zoneId = "zone-" + (idx % 50);
        int slot = (idx / 50) % 5;   // 0 = battery, 1 = meter, 2..4 = solar  (per zone of 10: 2 batteries, 2 meters, 6 solar)
        DeviceType type = slot == 0 ? DeviceType.BATTERY : slot == 1 ? DeviceType.METER : DeviceType.SOLAR;
        double baseW = 2500 + (idx % 7) * 250;
        double[] soc = { 40 + ThreadLocalRandom.current().nextDouble(50) };
        AtomicReference<String> mode = new AtomicReference<>("STOP");

        WebSocket.Listener listener = new WebSocket.Listener() {
            @Override
            public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
                try {
                    mode.set(MAPPER.readTree(data.toString()).get("action").asText());
                    commands.incrementAndGet();
                } catch (Exception ignored) {}
                ws.request(1);
                return null;
            }
        };

        WebSocket ws;
        try {
            WebSocket.Builder builder = client.newWebSocketBuilder();
            String secret = System.getenv("GW_DEVICE_SECRET");   // set it to connect to an ingestion node with auth enabled
            if (secret != null && !secret.isBlank()) {
                builder.header("Authorization", "Bearer " + DeviceTokens.sign(secret, deviceId, System.currentTimeMillis() / 1000 + 86_400));
            }
            ws = builder.buildAsync(URI.create(url + "?deviceId=" + deviceId), listener).join();
            connected.incrementAndGet();
        } catch (Exception e) {
            errors.incrementAndGet();
            return;
        }

        try {
            Thread.sleep(ThreadLocalRandom.current().nextLong(1000));   // desync devices
            long seq = 0;
            while (System.currentTimeMillis() < endAt) {
                long now = System.currentTimeMillis();
                double power = 0;
                if (type == DeviceType.SOLAR) {
                    double factor = (idx % 50) < stormZones && now >= stormAt && now < stormEnd ? 0.1 : 1.0;
                    power = baseW * factor * (0.95 + ThreadLocalRandom.current().nextDouble(0.1));
                } else if (type == DeviceType.METER) {
                    power = (3000 + (idx % 5) * 500) * (0.95 + ThreadLocalRandom.current().nextDouble(0.1));   // household load
                } else {
                    switch (mode.get()) {
                        case "DISCHARGE" -> { power = 2000;  soc[0] = Math.max(0, soc[0] - 0.5); }
                        case "CHARGE"    -> { power = -2000; soc[0] = Math.min(100, soc[0] + 0.5); }
                        default -> power = 0;
                    }
                }
                var msg = new TelemetryMessage(deviceId, zoneId, type, seq++, now, power,
                        type == DeviceType.BATTERY ? soc[0] : 0, 25 + ThreadLocalRandom.current().nextDouble(10), 0);
                String frame = ThreadLocalRandom.current().nextDouble(100) < badFramePct ? "{not-json" : MAPPER.writeValueAsString(msg);
                ws.sendText(frame, true).join();
                sent.incrementAndGet();
                Thread.sleep(1000);
            }
            ws.sendClose(WebSocket.NORMAL_CLOSURE, "bye").join();
        } catch (Exception e) {
            errors.incrementAndGet();
        }
    }
}
