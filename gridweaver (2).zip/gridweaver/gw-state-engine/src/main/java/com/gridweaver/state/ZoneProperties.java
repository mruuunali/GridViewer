package com.gridweaver.state;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "gridweaver.zone")
public class ZoneProperties {
    // Baseline mode (zones without meters): generation drop vs. slow-decaying peak
    private double stressRatio = 0.20;
    private double emergencyRatio = 0.40;
    private double clearRatio = 0.10;
    private long baselineDecayMs = 600_000;
    // Load mode (zones with meters): grid load = consumption / generation
    private double stressLoadRatio = 0.80;
    private double emergencyLoadRatio = 1.00;
    private double clearLoadRatio = 0.70;
    // Shared
    private long recoveryHoldMs = 30_000;
    private long dispatchIntervalMs = 1000;
    private double safetyMargin = 1.1;
    private long warmupMs = 10_000;
    // Neighbour borrowing
    private boolean neighbourBorrowing = true;
    private double lendFraction = 0.5;   // a lender gives at most this share of its spare batteries

    public double getStressRatio() { return stressRatio; }
    public void setStressRatio(double v) { this.stressRatio = v; }
    public double getEmergencyRatio() { return emergencyRatio; }
    public void setEmergencyRatio(double v) { this.emergencyRatio = v; }
    public double getClearRatio() { return clearRatio; }
    public void setClearRatio(double v) { this.clearRatio = v; }
    public long getBaselineDecayMs() { return baselineDecayMs; }
    public void setBaselineDecayMs(long v) { this.baselineDecayMs = v; }
    public double getStressLoadRatio() { return stressLoadRatio; }
    public void setStressLoadRatio(double v) { this.stressLoadRatio = v; }
    public double getEmergencyLoadRatio() { return emergencyLoadRatio; }
    public void setEmergencyLoadRatio(double v) { this.emergencyLoadRatio = v; }
    public double getClearLoadRatio() { return clearLoadRatio; }
    public void setClearLoadRatio(double v) { this.clearLoadRatio = v; }
    public long getRecoveryHoldMs() { return recoveryHoldMs; }
    public void setRecoveryHoldMs(long v) { this.recoveryHoldMs = v; }
    public long getDispatchIntervalMs() { return dispatchIntervalMs; }
    public void setDispatchIntervalMs(long v) { this.dispatchIntervalMs = v; }
    public double getSafetyMargin() { return safetyMargin; }
    public void setSafetyMargin(double v) { this.safetyMargin = v; }
    public long getWarmupMs() { return warmupMs; }
    public void setWarmupMs(long v) { this.warmupMs = v; }
    public boolean isNeighbourBorrowing() { return neighbourBorrowing; }
    public void setNeighbourBorrowing(boolean v) { this.neighbourBorrowing = v; }
    public double getLendFraction() { return lendFraction; }
    public void setLendFraction(double v) { this.lendFraction = v; }
}
