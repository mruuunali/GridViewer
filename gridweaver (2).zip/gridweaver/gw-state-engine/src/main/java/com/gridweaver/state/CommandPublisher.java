package com.gridweaver.state;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gridweaver.protocol.DeviceCommand;
import com.gridweaver.protocol.DeviceEvent;
import com.gridweaver.protocol.Topics;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class CommandPublisher {
    private final KafkaTemplate<String, String> kafka;
    private final ObjectMapper mapper;
    private final BatteryProperties props;

    public CommandPublisher(KafkaTemplate<String, String> kafka, ObjectMapper mapper, BatteryProperties props) {
        this.kafka = kafka;
        this.mapper = mapper;
        this.props = props;
    }

    public void commandFor(String deviceId, BatteryState newState, String reason) {
        DeviceCommand.Action action = switch (newState) {
            case DISCHARGING -> DeviceCommand.Action.DISCHARGE;
            case CHARGING -> DeviceCommand.Action.CHARGE;
            case IDLE, FAULT -> DeviceCommand.Action.STOP;
            case OFFLINE -> null;   // nothing to send to a disconnected device
        };
        if (action == null) return;
        double power = action == DeviceCommand.Action.STOP ? 0 : props.getDispatchPowerW();
        send(Topics.DEVICE_COMMANDS, deviceId,
                new DeviceCommand(UUID.randomUUID().toString(), deviceId, action, power, reason, System.currentTimeMillis()));
    }

    public void event(DeviceEvent e) { send(Topics.DEVICE_EVENTS, e.deviceId(), e); }

    public void deadLetter(String source, String reason, String payload) {
        send(Topics.TELEMETRY_DLQ, source, com.gridweaver.protocol.DeadLetter.of(source, reason, payload));
    }

    public void transfer(com.gridweaver.protocol.PowerTransfer t) {
        send(Topics.GRID_TRANSFERS, t.fromZone() + ">" + t.toZone(), t);
    }

    public void alert(com.gridweaver.protocol.ZoneAlert a) { send(Topics.GRID_ALERTS, a.zoneId(), a); }

    private void send(String topic, String key, Object payload) {
        try {
            kafka.send(topic, key, mapper.writeValueAsString(payload));
        } catch (JsonProcessingException e) {
            throw new IllegalStateException(e);
        }
    }
}
