package com.gridweaver.state;

import java.util.ArrayList;
import java.util.List;

/**
 * Which zones are electrically adjacent. For now: the zones form a cols x rows grid numbered row-major
 * ("zone-0" .. "zone-N"), and neighbours are the 4 orthogonal cells. In production this comes from the
 * PostGIS feeder/substation topology (Phase 5); callers only use neighbours(), so that swap is local.
 */
public class ZoneTopologyMap {
    private final int cols;
    private final int rows;

    public ZoneTopologyMap(int cols, int rows) {
        this.cols = cols;
        this.rows = rows;
    }

    public List<String> neighbours(String zoneId) {
        int n = parse(zoneId);
        if (n < 0 || n >= cols * rows) return List.of();
        int col = n % cols, row = n / cols;
        List<String> out = new ArrayList<>(4);
        if (row > 0) out.add("zone-" + (n - cols));
        if (row < rows - 1) out.add("zone-" + (n + cols));
        if (col > 0) out.add("zone-" + (n - 1));
        if (col < cols - 1) out.add("zone-" + (n + 1));
        return out;
    }

    private static int parse(String zoneId) {
        if (zoneId == null || !zoneId.startsWith("zone-")) return -1;
        try { return Integer.parseInt(zoneId.substring(5)); } catch (NumberFormatException e) { return -1; }
    }
}
