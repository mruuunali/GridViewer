package com.gridweaver.state;

import com.gridweaver.protocol.DeviceEvent;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.statemachine.StateMachine;
import org.springframework.statemachine.config.StateMachineFactory;
import org.springframework.statemachine.support.DefaultStateMachineContext;
import org.springframework.statemachine.StateMachineEventResult;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Rehydrate-per-event: load state from Redis -> build machine from the shared definition ->
 * feed ONE event -> persist -> discard machine. No 100k live machine instances.
 *
 * Per-device ordering: Kafka partitioning by deviceId covers telemetry; the striped lock covers
 * concurrent sources (telemetry vs. zone dispatch vs. heartbeat monitor).
 * ReentrantLock (not synchronized) so virtual threads don't pin the carrier while blocked on Redis.
 */
@Service
public class BatteryEngine {
    private static final int STRIPES = 1024;

    private final StateMachineFactory<BatteryState, BatteryEvent> factory;
    private final DeviceStore store;
    private final CommandPublisher publisher;
    private final ReentrantLock[] locks = new ReentrantLock[STRIPES];
    private final Timer handleTimer;
    private final Counter transitions;
    private final Counter denied;

    public BatteryEngine(@Qualifier("batteryStateMachineFactory") StateMachineFactory<BatteryState, BatteryEvent> factory, DeviceStore store,
                         CommandPublisher publisher, BatteryProperties props, MeterRegistry meters) {
        this.factory = factory;
        this.store = store;
        this.publisher = publisher;
        BatteryGuards.props = props;
        for (int i = 0; i < STRIPES; i++) locks[i] = new ReentrantLock();
        this.handleTimer = meters.timer("gridweaver.state.handle");
        this.transitions = meters.counter("gridweaver.state.transitions");
        this.denied = meters.counter("gridweaver.state.denied");
    }

    /** @return the new state if a transition happened. */
    public Optional<BatteryState> handle(String deviceId, BatteryEvent event, String reason) {
        ReentrantLock lock = locks[Math.floorMod(deviceId.hashCode(), STRIPES)];
        lock.lock();
        try {
            return handleTimer.record(() -> doHandle(deviceId, event, reason));
        } finally {
            lock.unlock();
        }
    }

    private Optional<BatteryState> doHandle(String deviceId, BatteryEvent event, String reason) {
        Optional<DeviceStore.Snapshot> maybe = store.get(deviceId);
        if (maybe.isEmpty()) return Optional.empty();
        DeviceStore.Snapshot snap = maybe.get();
        long now = System.currentTimeMillis();

        StateMachine<BatteryState, BatteryEvent> sm = factory.getStateMachine(deviceId);
        try {
            sm.stopReactively().block();
            sm.getStateMachineAccessor().doWithAllRegions(access ->
                    access.resetStateMachineReactively(
                            new DefaultStateMachineContext<>(snap.state(), null, null, null)).block());
            sm.startReactively().block();

            Message<BatteryEvent> msg = MessageBuilder.withPayload(event)
                    .setHeader(BatteryGuards.H_SOC, snap.soc())
                    .setHeader(BatteryGuards.H_TEMP, snap.tempC())
                    .setHeader(BatteryGuards.H_LAST_TRANSITION, snap.lastTransition())
                    .setHeader(BatteryGuards.H_NOW, now)
                    .build();

            boolean accepted = sm.sendEvent(Mono.just(msg)).collectList().block().stream()
                    .anyMatch(r -> r.getResultType() == StateMachineEventResult.ResultType.ACCEPTED);
            BatteryState newState = sm.getState().getId();

            if (!accepted || newState == snap.state()) {
                denied.increment();
                return Optional.empty();
            }

            store.saveState(deviceId, newState, now);
            publisher.event(new DeviceEvent(deviceId, snap.zone(), snap.state().name(), newState.name(),
                    event.name(), reason, now));
            publisher.commandFor(deviceId, newState, reason);
            transitions.increment();
            return Optional.of(newState);
        } finally {
            sm.stopReactively().block();
        }
    }
}
