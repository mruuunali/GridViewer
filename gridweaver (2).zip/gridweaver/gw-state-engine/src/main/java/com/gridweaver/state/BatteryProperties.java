package com.gridweaver.state;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "gridweaver.battery")
public class BatteryProperties {
    private double minSocPct = 20;
    private double fullSocPct = 98;
    private double maxTempC = 55;
    private double faultTempC = 60;
    private double faultClearTempC = 50;
    private long cooldownMs = 10_000;
    private double dispatchPowerW = 2000;
    private long heartbeatTimeoutMs = 15_000;

    public double getMinSocPct() { return minSocPct; }
    public void setMinSocPct(double v) { this.minSocPct = v; }
    public double getFullSocPct() { return fullSocPct; }
    public void setFullSocPct(double v) { this.fullSocPct = v; }
    public double getMaxTempC() { return maxTempC; }
    public void setMaxTempC(double v) { this.maxTempC = v; }
    public double getFaultTempC() { return faultTempC; }
    public void setFaultTempC(double v) { this.faultTempC = v; }
    public double getFaultClearTempC() { return faultClearTempC; }
    public void setFaultClearTempC(double v) { this.faultClearTempC = v; }
    public long getCooldownMs() { return cooldownMs; }
    public void setCooldownMs(long v) { this.cooldownMs = v; }
    public double getDispatchPowerW() { return dispatchPowerW; }
    public void setDispatchPowerW(double v) { this.dispatchPowerW = v; }
    public long getHeartbeatTimeoutMs() { return heartbeatTimeoutMs; }
    public void setHeartbeatTimeoutMs(long v) { this.heartbeatTimeoutMs = v; }
}
