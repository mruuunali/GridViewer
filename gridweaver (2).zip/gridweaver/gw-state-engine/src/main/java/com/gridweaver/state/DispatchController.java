package com.gridweaver.state;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class DispatchController {
    private final DispatchService dispatch;
    private final DeviceStore store;
    private final ZoneController zones;

    public DispatchController(DispatchService dispatch, DeviceStore store, ZoneController zones) {
        this.dispatch = dispatch;
        this.store = store;
        this.zones = zones;
    }

    /** Manual override / testing: POST /api/zones/zone-3/dispatch?event=GRID_DEFICIT&limit=50 */
    @PostMapping("/zones/{zone}/dispatch")
    public DispatchService.Result dispatch(@PathVariable String zone, @RequestParam BatteryEvent event,
                                           @RequestParam(defaultValue = "100") int limit) {
        return dispatch.dispatch(zone, event, limit);
    }

    /** Live zone states (NORMAL / STRESSED / EMERGENCY / RECOVERING) with deficit and committed power. */
    @GetMapping("/zones")
    public List<ZoneController.ZoneStatus> zones() {
        return zones.snapshot();
    }

    @GetMapping("/devices/{id}")
    public ResponseEntity<DeviceStore.Snapshot> device(@PathVariable String id) {
        return store.get(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
}
