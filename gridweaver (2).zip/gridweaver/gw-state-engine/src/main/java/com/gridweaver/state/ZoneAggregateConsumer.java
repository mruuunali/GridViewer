package com.gridweaver.state;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gridweaver.protocol.Topics;
import com.gridweaver.protocol.ZoneAggregate;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class ZoneAggregateConsumer {
    private final ObjectMapper mapper;
    private final ZoneController controller;

    public ZoneAggregateConsumer(ObjectMapper mapper, ZoneController controller) {
        this.mapper = mapper;
        this.controller = controller;
    }

    /** Keyed by zoneId, so one zone's updates arrive in order on one thread. */
    @KafkaListener(topics = Topics.ZONE_AGG, groupId = "gw-zone-controller", concurrency = "2")
    public void onAggregate(String json) throws Exception {
        controller.onAggregate(mapper.readValue(json, ZoneAggregate.class));
    }
}
