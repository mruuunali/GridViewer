package com.gridweaver.state;

import com.gridweaver.protocol.PowerTransfer;
import com.gridweaver.protocol.ZoneAggregate;
import com.gridweaver.protocol.ZoneAlert;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.statemachine.StateMachine;
import org.springframework.statemachine.config.StateMachineFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Grid-level brain. Two detection modes, chosen per zone:
 *
 *  LOAD mode (zone has meters): grid load = consumption / generation.
 *      >= 0.8 STRESSED, >= 1.0 EMERGENCY, < 0.7 clear.  Deficit = consumption - generation.
 *  BASELINE mode (no meters): generation drop vs. a slow-decaying peak (20% / 40% / 10%).
 *
 * Either way: hysteresis drives the zone state machine, STRESSED/EMERGENCY keep topping up discharge
 * dispatch until committed battery power covers deficit * safety margin (committed = batteries already
 * DISCHARGING in this zone + batteries borrowed from neighbours), and recovery releases them all.
 *
 * Regional balancing: when the zone's own batteries cannot cover the deficit, it borrows from adjacent
 * zones that are NORMAL, most spare capacity first, taking at most lend-fraction of a lender's spare
 * batteries. Each loan is published as a PowerTransfer (grid.transfers) and ended on recovery.
 */
@Component
public class ZoneController {
    public record ZoneStatus(String zone, String state, String mode, double baselineW, double generationW,
                             double consumptionW, double dischargeW, double loadRatio, double deficitW,
                             double committedW, int batteries, int solarNodes, int meters, int borrowedBatteries) {}

    private static final class Tracker {
        final String zone;
        final StateMachine<ZoneState, ZoneEvent> sm;
        final ReentrantLock lock = new ReentrantLock();
        final Map<String, List<String>> lent = new HashMap<>();   // lender zone -> device ids borrowed from it
        boolean loadMode;
        double baselineW, generationW, consumptionW, dischargeW, loadRatio, deficitW, committedW;
        int batteries, solarNodes, meters;
        long firstSeen, lastUpdate, lastDispatchAt, okSince;

        Tracker(String zone, StateMachine<ZoneState, ZoneEvent> sm) { this.zone = zone; this.sm = sm; }

        int borrowed() { return lent.values().stream().mapToInt(List::size).sum(); }
    }

    private final StateMachineFactory<ZoneState, ZoneEvent> factory;
    private final DispatchService dispatch;
    private final CommandPublisher publisher;
    private final ZoneProperties zp;
    private final BatteryProperties bp;
    private final ZoneTopologyMap topology;
    private final DeviceStore store;
    private final Timer ingestToDecision;
    private final Counter borrowEvents;
    private final ConcurrentHashMap<String, Tracker> trackers = new ConcurrentHashMap<>();

    public ZoneController(@Qualifier("zoneStateMachineFactory") StateMachineFactory<ZoneState, ZoneEvent> factory,
                          DispatchService dispatch, CommandPublisher publisher,
                          ZoneProperties zp, BatteryProperties bp, ZoneTopologyMap topology, DeviceStore store,
                          MeterRegistry meters) {
        this.factory = factory;
        this.dispatch = dispatch;
        this.publisher = publisher;
        this.zp = zp;
        this.bp = bp;
        this.topology = topology;
        this.store = store;
        this.ingestToDecision = meters.timer("gridweaver.zone.ingest_to_decision");
        this.borrowEvents = meters.counter("gridweaver.zone.borrow_events");
    }

    public void onAggregate(ZoneAggregate a) {
        if (a.zoneId() == null || a.solarCount() == 0) return;
        Tracker t = trackers.computeIfAbsent(a.zoneId(), this::newTracker);
        t.lock.lock();
        try {
            process(t, a);
        } finally {
            t.lock.unlock();
        }
    }

    public List<ZoneStatus> snapshot() {
        return trackers.values().stream()
                .map(t -> new ZoneStatus(t.zone, t.sm.getState().getId().name(), t.loadMode ? "LOAD" : "BASELINE",
                        t.baselineW, t.generationW, t.consumptionW, t.dischargeW, t.loadRatio, t.deficitW,
                        t.committedW, t.batteries, t.solarNodes, t.meters, t.borrowed()))
                .sorted(Comparator.comparing(ZoneStatus::zone))
                .toList();
    }

    private Tracker newTracker(String zone) {
        StateMachine<ZoneState, ZoneEvent> sm = factory.getStateMachine("zone-" + zone);
        sm.startReactively().block();
        return new Tracker(zone, sm);
    }

    private void process(Tracker t, ZoneAggregate a) {
        long now = System.currentTimeMillis();
        if (a.lastIngestAt() > 0) ingestToDecision.record(Math.max(0, now - a.lastIngestAt()), TimeUnit.MILLISECONDS);
        if (t.firstSeen == 0) t.firstSeen = now;

        ZoneState state = t.sm.getState().getId();

        // Baseline: slow-decaying peak, frozen outside NORMAL so a storm cannot erode it.
        if (state == ZoneState.NORMAL) {
            double decay = t.lastUpdate == 0 ? 0 : Math.min(1.0, (now - t.lastUpdate) / (double) zp.getBaselineDecayMs());
            t.baselineW = Math.max(a.generationW(), t.baselineW * (1 - decay));
        }
        t.lastUpdate = now;

        double deficit, ratio;
        int level;   // 2 = emergency, 1 = stressed, 0 = clear, -1 = inside hysteresis band (hold)
        boolean loadMode = a.meterCount() > 0;
        if (loadMode) {
            ratio = a.consumptionW() / Math.max(a.generationW(), 1.0);
            deficit = Math.max(0, a.consumptionW() - a.generationW());
            level = ratio >= zp.getEmergencyLoadRatio() ? 2
                    : ratio >= zp.getStressLoadRatio() ? 1
                    : ratio < zp.getClearLoadRatio() ? 0 : -1;
        } else {
            deficit = Math.max(0, t.baselineW - a.generationW());
            ratio = t.baselineW > 0 ? deficit / t.baselineW : 0;
            level = ratio >= zp.getEmergencyRatio() ? 2
                    : ratio >= zp.getStressRatio() ? 1
                    : ratio < zp.getClearRatio() ? 0 : -1;
        }

        t.loadMode = loadMode;
        t.loadRatio = loadMode ? ratio : 0;
        t.generationW = a.generationW();
        t.consumptionW = a.consumptionW();
        t.dischargeW = a.dischargeW();
        t.deficitW = deficit;
        t.batteries = a.batteryCount();
        t.solarNodes = a.solarCount();
        t.meters = a.meterCount();

        if (now - t.firstSeen < zp.getWarmupMs()) return;   // devices still connecting: don't act yet

        ZoneEvent ev = decide(t, state, level, now);
        if (ev != null) {
            t.sm.sendEvent(Mono.just(MessageBuilder.withPayload(ev).build())).collectList().block();
            ZoneState next = t.sm.getState().getId();
            if (next != state) {
                if (ev == ZoneEvent.ZONE_OK) {
                    dispatch.dispatch(t.zone, BatteryEvent.GRID_NORMAL, Integer.MAX_VALUE);
                    releaseLoans(t, now);
                }
                store.saveZoneState(t.zone, next.name());   // lets a restarted gateway show the true state immediately
                publisher.alert(new ZoneAlert(t.zone, state.name(), next.name(), t.baselineW, a.generationW(),
                        deficit, t.committedW, now));
                state = next;
            }
        }

        if (state == ZoneState.STRESSED || state == ZoneState.EMERGENCY) topUp(t, deficit, now);
    }

    private ZoneEvent decide(Tracker t, ZoneState s, int level, long now) {
        if (s != ZoneState.RECOVERING) t.okSince = 0;

        switch (s) {
            case NORMAL:
                return level == 2 ? ZoneEvent.ZONE_EMERGENCY : level == 1 ? ZoneEvent.ZONE_STRESS : null;
            case STRESSED:
                return level == 2 ? ZoneEvent.ZONE_EMERGENCY : level == 0 ? ZoneEvent.ZONE_OK : null;
            case EMERGENCY:
                return level == 0 ? ZoneEvent.ZONE_OK : null;
            case RECOVERING:
                if (level == 2) return ZoneEvent.ZONE_EMERGENCY;
                if (level == 1) return ZoneEvent.ZONE_STRESS;
                if (level == 0) {
                    if (t.okSince == 0) t.okSince = now;
                    return now - t.okSince >= zp.getRecoveryHoldMs() ? ZoneEvent.ZONE_RECOVERED : null;
                }
                t.okSince = 0;
                return null;
            default:
                return null;
        }
    }

    private void topUp(Tracker t, double deficit, long now) {
        if (now - t.lastDispatchAt < zp.getDispatchIntervalMs()) return;
        pruneLoans(t, now);

        double power = bp.getDispatchPowerW();
        double committed = (dispatch.dischargingCount(t.zone) + t.borrowed()) * power;
        t.committedW = committed;
        double remaining = deficit * zp.getSafetyMargin() - committed;
        if (remaining <= power * 0.5) return;

        t.lastDispatchAt = now;
        int needed = (int) Math.ceil(remaining / power);
        DispatchService.Result local = dispatch.dispatch(t.zone, BatteryEvent.GRID_DEFICIT, needed);

        int shortfall = needed - local.transitioned();
        if (shortfall > 0 && zp.isNeighbourBorrowing()) borrow(t, shortfall, now);
    }

    /** Ask adjacent NORMAL zones for batteries, most spare capacity first. */
    private void borrow(Tracker t, int shortfall, long now) {
        record Offer(String zone, int spare) {}
        List<Offer> offers = new ArrayList<>();
        for (String n : topology.neighbours(t.zone)) {
            Tracker nt = trackers.get(n);
            if (nt == null || nt.sm.getState().getId() != ZoneState.NORMAL) continue;   // never borrow from a stressed zone
            int spare = dispatch.spareCount(n);
            if (spare > 0) offers.add(new Offer(n, spare));
        }
        offers.sort(Comparator.comparingInt(Offer::spare).reversed());

        int remaining = shortfall;
        for (Offer o : offers) {
            if (remaining <= 0) break;
            // floor, with no minimum of 1: a lender with 1 spare battery keeps it, so retries can't drain a neighbour
            int take = Math.min(remaining, (int) Math.floor(o.spare() * zp.getLendFraction()));
            if (take <= 0) continue;
            DispatchService.Result r = dispatch.dispatch(o.zone(), BatteryEvent.GRID_DEFICIT, take,
                    "loan " + o.zone() + " -> " + t.zone);
            if (r.deviceIds().isEmpty()) continue;
            t.lent.computeIfAbsent(o.zone(), k -> new ArrayList<>()).addAll(r.deviceIds());
            remaining -= r.deviceIds().size();
            borrowEvents.increment();
            publishLoan(t, o.zone(), now);
        }
    }

    /** Drop loaned batteries that stopped discharging (e.g. hit their SoC floor) and refresh the transfer. */
    private void pruneLoans(Tracker t, long now) {
        for (var it = t.lent.entrySet().iterator(); it.hasNext(); ) {
            var e = it.next();
            List<String> alive = dispatch.stillDischarging(e.getValue());
            if (alive.size() == e.getValue().size()) continue;
            if (alive.isEmpty()) {
                it.remove();
                publisher.transfer(new PowerTransfer(e.getKey(), t.zone, 0, 0, false, now));
            } else {
                e.setValue(new ArrayList<>(alive));
                publishLoan(t, e.getKey(), now);
            }
        }
    }

    private void releaseLoans(Tracker t, long now) {
        for (var e : t.lent.entrySet()) {
            dispatch.release(e.getValue(), "loan ended " + e.getKey() + " -> " + t.zone);
            publisher.transfer(new PowerTransfer(e.getKey(), t.zone, 0, 0, false, now));
        }
        t.lent.clear();
    }

    private void publishLoan(Tracker t, String lender, long now) {
        int n = t.lent.getOrDefault(lender, List.of()).size();
        publisher.transfer(new PowerTransfer(lender, t.zone, n * bp.getDispatchPowerW(), n, true, now));
    }
}
