package com.gridweaver.state;

public enum ZoneState { NORMAL, STRESSED, EMERGENCY, RECOVERING }
