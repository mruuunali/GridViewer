package com.gridweaver.state;

public enum ZoneEvent { ZONE_STRESS, ZONE_EMERGENCY, ZONE_OK, ZONE_RECOVERED }
