package com.gridweaver.state;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class HeartbeatMonitor {
    private final DeviceStore store;
    private final BatteryEngine engine;
    private final BatteryProperties props;

    public HeartbeatMonitor(DeviceStore store, BatteryEngine engine, BatteryProperties props) {
        this.store = store;
        this.engine = engine;
        this.props = props;
    }

    @Scheduled(fixedDelay = 5000)
    public void sweep() {
        for (String id : store.staleBatteries(props.getHeartbeatTimeoutMs())) {
            engine.handle(id, BatteryEvent.HEARTBEAT_LOST, "heartbeat timeout");
            store.forgetLastSeen(id);   // re-added on next telemetry
        }
    }
}
