package com.gridweaver.state;

import com.gridweaver.protocol.TelemetryMessage;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Latest state per battery in Redis:
 *   gw:device:{id}          hash  state, soc, tempC, zone, lastTransition
 *   gw:zone:{zone}:batteries set  deviceIds
 *   gw:lastseen             zset  deviceId -> last telemetry time (for heartbeat timeout)
 */
@Component
public class DeviceStore {
    public record Snapshot(String deviceId, BatteryState state, double soc, double tempC, String zone, long lastTransition) {}

    private static final String LASTSEEN = "gw:lastseen";
    private static final String BATTERY_STATES = "gw:battery-state";   // deviceId -> "zone|STATE", read by the gateway at startup
    private static final String ZONE_STATES = "gw:zone-state";         // zoneId -> STATE
    private final StringRedisTemplate redis;

    public DeviceStore(StringRedisTemplate redis) { this.redis = redis; }

    private static String key(String id) { return "gw:device:" + id; }
    private static String zoneKey(String zone) { return "gw:zone:" + zone + ":batteries"; }

    public void upsertTelemetry(TelemetryMessage m) {
        String k = key(m.deviceId());
        boolean isNew = !Boolean.TRUE.equals(redis.hasKey(k));
        Map<String, String> f = new HashMap<>();
        f.put("soc", Double.toString(m.socPct()));
        f.put("tempC", Double.toString(m.tempC()));
        f.put("zone", m.zoneId());
        if (isNew) {
            f.put("state", BatteryState.IDLE.name());
            f.put("lastTransition", "0");
            redis.opsForSet().add(zoneKey(m.zoneId()), m.deviceId());
        }
        redis.opsForHash().putAll(k, f);
        redis.opsForZSet().add(LASTSEEN, m.deviceId(), m.receivedAt() > 0 ? m.receivedAt() : System.currentTimeMillis());
    }

    public Optional<Snapshot> get(String id) {
        Map<Object, Object> h = redis.opsForHash().entries(key(id));
        if (h.isEmpty()) return Optional.empty();
        return Optional.of(new Snapshot(
                id,
                BatteryState.valueOf((String) h.getOrDefault("state", "IDLE")),
                Double.parseDouble((String) h.getOrDefault("soc", "0")),
                Double.parseDouble((String) h.getOrDefault("tempC", "0")),
                (String) h.getOrDefault("zone", "unknown"),
                Long.parseLong((String) h.getOrDefault("lastTransition", "0"))));
    }

    public void saveState(String id, BatteryState state, long now) {
        redis.opsForHash().putAll(key(id), Map.of("state", state.name(), "lastTransition", Long.toString(now)));
        Object zone = redis.opsForHash().get(key(id), "zone");
        if (zone != null) redis.opsForHash().put(BATTERY_STATES, id, zone + "|" + state.name());
    }

    public void saveZoneState(String zone, String state) {
        redis.opsForHash().put(ZONE_STATES, zone, state);
    }

    public Set<String> batteriesInZone(String zone) {
        Set<String> s = redis.opsForSet().members(zoneKey(zone));
        return s == null ? Set.of() : s;
    }

    public Set<String> staleBatteries(long olderThanMs) {
        Set<String> s = redis.opsForZSet().rangeByScore(LASTSEEN, 0, System.currentTimeMillis() - olderThanMs);
        return s == null ? Set.of() : s;
    }

    public void forgetLastSeen(String id) { redis.opsForZSet().remove(LASTSEEN, id); }
}
