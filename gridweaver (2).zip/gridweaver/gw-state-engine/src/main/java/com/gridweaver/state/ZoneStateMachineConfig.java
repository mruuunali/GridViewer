package com.gridweaver.state;

import org.springframework.context.annotation.Configuration;
import org.springframework.statemachine.config.EnableStateMachineFactory;
import org.springframework.statemachine.config.EnumStateMachineConfigurerAdapter;
import org.springframework.statemachine.config.builders.StateMachineConfigurationConfigurer;
import org.springframework.statemachine.config.builders.StateMachineStateConfigurer;
import org.springframework.statemachine.config.builders.StateMachineTransitionConfigurer;

import java.util.EnumSet;

import static com.gridweaver.state.ZoneEvent.*;
import static com.gridweaver.state.ZoneState.*;

/** Only a few hundred zones exist, so (unlike batteries) one live machine per zone is fine. */
@Configuration
@EnableStateMachineFactory(name = "zoneStateMachineFactory")
public class ZoneStateMachineConfig extends EnumStateMachineConfigurerAdapter<ZoneState, ZoneEvent> {

    @Override
    public void configure(StateMachineConfigurationConfigurer<ZoneState, ZoneEvent> config) throws Exception {
        config.withConfiguration().autoStartup(false);
    }

    @Override
    public void configure(StateMachineStateConfigurer<ZoneState, ZoneEvent> states) throws Exception {
        states.withStates().initial(NORMAL).states(EnumSet.allOf(ZoneState.class));
    }

    @Override
    public void configure(StateMachineTransitionConfigurer<ZoneState, ZoneEvent> t) throws Exception {
        t
            .withExternal().source(NORMAL).target(STRESSED).event(ZONE_STRESS)
            .and().withExternal().source(NORMAL).target(EMERGENCY).event(ZONE_EMERGENCY)
            .and().withExternal().source(STRESSED).target(EMERGENCY).event(ZONE_EMERGENCY)
            .and().withExternal().source(STRESSED).target(NORMAL).event(ZONE_OK)
            .and().withExternal().source(EMERGENCY).target(RECOVERING).event(ZONE_OK)
            .and().withExternal().source(RECOVERING).target(NORMAL).event(ZONE_RECOVERED)
            .and().withExternal().source(RECOVERING).target(STRESSED).event(ZONE_STRESS)
            .and().withExternal().source(RECOVERING).target(EMERGENCY).event(ZONE_EMERGENCY);
    }
}
