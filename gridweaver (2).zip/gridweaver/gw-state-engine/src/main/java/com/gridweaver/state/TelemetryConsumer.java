package com.gridweaver.state;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gridweaver.protocol.DeviceType;
import com.gridweaver.protocol.TelemetryMessage;
import com.gridweaver.protocol.Topics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/** Kafka partitions by deviceId, so one device's telemetry is processed in order. */
@Component
public class TelemetryConsumer {
    private static final Logger log = LoggerFactory.getLogger(TelemetryConsumer.class);

    private final ObjectMapper mapper;
    private final DeviceStore store;
    private final BatteryEngine engine;
    private final BatteryProperties props;
    private final CommandPublisher publisher;

    public TelemetryConsumer(ObjectMapper mapper, DeviceStore store, BatteryEngine engine, BatteryProperties props,
                             CommandPublisher publisher) {
        this.mapper = mapper;
        this.store = store;
        this.engine = engine;
        this.props = props;
        this.publisher = publisher;
    }

    @KafkaListener(topics = Topics.TELEMETRY_RAW, concurrency = "6")
    public void onTelemetry(@Payload(required = false) String json) {
        if (json == null) return;   // tombstone from ingestion (device disconnected); heartbeat monitor handles batteries
        TelemetryMessage m;
        try {
            m = mapper.readValue(json, TelemetryMessage.class);
        } catch (Exception e) {
            log.debug("bad telemetry: {}", e.toString());
            publisher.deadLetter("state-engine", "parse error: " + e.getClass().getSimpleName(), json);
            return;
        }
        if (m.type() != DeviceType.BATTERY) return;   // solar goes to the zone aggregator (Phase 3)

        store.upsertTelemetry(m);
        BatteryEvent derived = deriveEvent(m);
        if (derived != null) engine.handle(m.deviceId(), derived, "telemetry");
    }

    /** Local, device-driven events. Grid-driven events (deficit/surplus) come from the zone level. */
    private BatteryEvent deriveEvent(TelemetryMessage m) {
        BatteryState state = store.get(m.deviceId()).map(DeviceStore.Snapshot::state).orElse(BatteryState.IDLE);
        return switch (state) {
            case OFFLINE -> BatteryEvent.HEARTBEAT_RESTORED;
            case FAULT -> m.tempC() < props.getFaultClearTempC() ? BatteryEvent.FAULT_CLEARED : null;
            case DISCHARGING -> m.tempC() > props.getFaultTempC() ? BatteryEvent.OVER_TEMP
                    : m.socPct() <= props.getMinSocPct() ? BatteryEvent.SOC_LOW : null;
            case CHARGING -> m.tempC() > props.getFaultTempC() ? BatteryEvent.OVER_TEMP
                    : m.socPct() >= props.getFullSocPct() ? BatteryEvent.SOC_FULL : null;
            case IDLE -> m.tempC() > props.getFaultTempC() ? BatteryEvent.OVER_TEMP : null;
        };
    }
}
