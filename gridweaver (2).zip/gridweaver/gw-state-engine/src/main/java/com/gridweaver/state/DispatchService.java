package com.gridweaver.state;

import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Sends a grid event to the best-suited batteries in a zone.
 * Candidate rules per event, so repeated top-ups never waste slots on batteries that can't act:
 *   GRID_DEFICIT : IDLE/CHARGING with SoC above the floor, highest SoC first
 *   GRID_SURPLUS : IDLE/DISCHARGING with SoC below full, lowest SoC first
 *   GRID_NORMAL  : CHARGING/DISCHARGING (release everything back to IDLE)
 * Results carry the device ids that actually changed state, so a loan to a neighbour zone can be
 * released later without touching the lender's own batteries.
 */
@Service
public class DispatchService {
    private final DeviceStore store;
    private final BatteryEngine engine;
    private final BatteryProperties props;

    public DispatchService(DeviceStore store, BatteryEngine engine, BatteryProperties props) {
        this.store = store;
        this.engine = engine;
        this.props = props;
    }

    public record Result(int candidates, int selected, int transitioned, long tookMs, List<String> deviceIds) {}

    public Result dispatch(String zone, BatteryEvent event, int limit) {
        return dispatch(zone, event, limit, "zone dispatch " + zone);
    }

    public Result dispatch(String zone, BatteryEvent event, int limit, String reason) {
        long t0 = System.currentTimeMillis();
        var all = store.batteriesInZone(zone);
        List<DeviceStore.Snapshot> ranked = all.stream()
                .map(store::get).flatMap(Optional::stream)
                .filter(s -> eligible(s, event))
                .sorted(event == BatteryEvent.GRID_SURPLUS
                        ? Comparator.comparingDouble(DeviceStore.Snapshot::soc)
                        : Comparator.comparingDouble(DeviceStore.Snapshot::soc).reversed())
                .limit(limit)
                .toList();

        List<String> changed;
        try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
            List<Future<String>> futures = ranked.stream()
                    .map(s -> exec.submit(() -> engine.handle(s.deviceId(), event, reason).isPresent() ? s.deviceId() : null))
                    .toList();
            changed = futures.stream().map(f -> {
                try { return f.get(); } catch (Exception e) { return null; }
            }).filter(Objects::nonNull).toList();
        }
        return new Result(all.size(), ranked.size(), changed.size(), System.currentTimeMillis() - t0, changed);
    }

    /** Batteries in the zone that could still start discharging (used to rank lenders). */
    public int spareCount(String zone) {
        return (int) store.batteriesInZone(zone).stream()
                .map(store::get).flatMap(Optional::stream)
                .filter(s -> eligible(s, BatteryEvent.GRID_DEFICIT))
                .count();
    }

    public int dischargingCount(String zone) {
        return (int) store.batteriesInZone(zone).stream()
                .map(store::get).flatMap(Optional::stream)
                .filter(s -> s.state() == BatteryState.DISCHARGING)
                .count();
    }

    /** Subset of the given devices that are still DISCHARGING (loans drop out when a battery hits its SoC floor). */
    public List<String> stillDischarging(List<String> ids) {
        return ids.stream()
                .filter(id -> store.get(id).map(s -> s.state() == BatteryState.DISCHARGING).orElse(false))
                .toList();
    }

    /** Return specific batteries to IDLE (ends a loan). */
    public void release(List<String> ids, String reason) {
        if (ids.isEmpty()) return;
        try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
            for (String id : ids) exec.submit(() -> engine.handle(id, BatteryEvent.GRID_NORMAL, reason));
        }
    }

    private boolean eligible(DeviceStore.Snapshot s, BatteryEvent event) {
        BatteryState st = s.state();
        return switch (event) {
            case GRID_DEFICIT -> (st == BatteryState.IDLE || st == BatteryState.CHARGING) && s.soc() > props.getMinSocPct();
            case GRID_SURPLUS -> (st == BatteryState.IDLE || st == BatteryState.DISCHARGING) && s.soc() < props.getFullSocPct();
            case GRID_NORMAL -> st == BatteryState.CHARGING || st == BatteryState.DISCHARGING;
            default -> st != BatteryState.FAULT && st != BatteryState.OFFLINE;
        };
    }
}
