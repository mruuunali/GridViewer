package com.gridweaver.state;

public enum BatteryEvent {
    GRID_DEFICIT, GRID_SURPLUS, GRID_NORMAL,
    SOC_LOW, SOC_FULL,
    OVER_TEMP, FAULT_CLEARED,
    HEARTBEAT_LOST, HEARTBEAT_RESTORED
}
