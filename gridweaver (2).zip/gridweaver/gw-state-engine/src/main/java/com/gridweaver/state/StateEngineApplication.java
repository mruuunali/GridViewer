package com.gridweaver.state;

import com.gridweaver.protocol.Topics;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@EnableConfigurationProperties({BatteryProperties.class, ZoneProperties.class})
public class StateEngineApplication {
    public static void main(String[] args) { SpringApplication.run(StateEngineApplication.class, args); }

    @Bean NewTopic deviceCommands() { return TopicBuilder.name(Topics.DEVICE_COMMANDS).partitions(12).replicas(1).build(); }
    @Bean NewTopic zoneAgg()        { return TopicBuilder.name(Topics.ZONE_AGG).partitions(6).replicas(1).build(); }
    @Bean NewTopic gridTransfers()  { return TopicBuilder.name(Topics.GRID_TRANSFERS).partitions(3).replicas(1).build(); }
    @Bean NewTopic gridAlerts()     { return TopicBuilder.name(Topics.GRID_ALERTS).partitions(6).replicas(1).build(); }
    @Bean NewTopic deviceEvents()   { return TopicBuilder.name(Topics.DEVICE_EVENTS).partitions(12).replicas(1).build(); }

    @Bean
    ZoneTopologyMap zoneTopology(@Value("${gridweaver.topology.cols:10}") int cols,
                                 @Value("${gridweaver.topology.rows:5}") int rows) {
        return new ZoneTopologyMap(cols, rows);
    }
}
