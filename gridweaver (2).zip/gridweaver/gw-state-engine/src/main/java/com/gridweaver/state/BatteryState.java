package com.gridweaver.state;

public enum BatteryState { IDLE, CHARGING, DISCHARGING, FAULT, OFFLINE }
