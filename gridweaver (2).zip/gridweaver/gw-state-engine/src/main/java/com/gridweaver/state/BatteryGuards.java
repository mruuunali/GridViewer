package com.gridweaver.state;

import org.springframework.statemachine.guard.Guard;

/**
 * Guards read the device's extended state from message headers, populated per event by BatteryEngine.
 * (Machines are rebuilt per event, so nothing is kept in the machine itself.)
 */
public final class BatteryGuards {
    public static final String H_SOC = "soc";
    public static final String H_TEMP = "tempC";
    public static final String H_LAST_TRANSITION = "lastTransition";
    public static final String H_NOW = "now";

    // Set once at startup from config (see BatteryProperties).
    static volatile BatteryProperties props = new BatteryProperties();

    private BatteryGuards() {}

    public static Guard<BatteryState, BatteryEvent> canDischarge() {
        return ctx -> num(ctx.getMessageHeaders().get(H_SOC)) > props.getMinSocPct()
                && num(ctx.getMessageHeaders().get(H_TEMP)) < props.getMaxTempC()
                && cooledDown(ctx.getMessageHeaders());
    }

    public static Guard<BatteryState, BatteryEvent> canCharge() {
        return ctx -> num(ctx.getMessageHeaders().get(H_SOC)) < props.getFullSocPct()
                && num(ctx.getMessageHeaders().get(H_TEMP)) < props.getMaxTempC()
                && cooledDown(ctx.getMessageHeaders());
    }

    public static Guard<BatteryState, BatteryEvent> canClearFault() {
        return ctx -> num(ctx.getMessageHeaders().get(H_TEMP)) < props.getFaultClearTempC();
    }

    private static boolean cooledDown(java.util.Map<String, Object> h) {
        return num(h.get(H_NOW)) - num(h.get(H_LAST_TRANSITION)) >= props.getCooldownMs();  // anti-flapping
    }

    private static double num(Object o) {
        return o instanceof Number n ? n.doubleValue() : 0d;
    }
}
