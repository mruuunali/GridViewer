package com.gridweaver.state;

import org.springframework.context.annotation.Configuration;
import org.springframework.statemachine.config.EnableStateMachineFactory;
import org.springframework.statemachine.config.EnumStateMachineConfigurerAdapter;
import org.springframework.statemachine.config.builders.StateMachineConfigurationConfigurer;
import org.springframework.statemachine.config.builders.StateMachineStateConfigurer;
import org.springframework.statemachine.config.builders.StateMachineTransitionConfigurer;

import java.util.EnumSet;

import static com.gridweaver.state.BatteryEvent.*;
import static com.gridweaver.state.BatteryState.*;

/** ONE shared definition; per-device machines are created from it on demand (see BatteryEngine). */
@Configuration
@EnableStateMachineFactory(name = "batteryStateMachineFactory")
public class BatteryStateMachineConfig extends EnumStateMachineConfigurerAdapter<BatteryState, BatteryEvent> {

    @Override
    public void configure(StateMachineConfigurationConfigurer<BatteryState, BatteryEvent> config) throws Exception {
        config.withConfiguration().autoStartup(false);
    }

    @Override
    public void configure(StateMachineStateConfigurer<BatteryState, BatteryEvent> states) throws Exception {
        states.withStates().initial(IDLE).states(EnumSet.allOf(BatteryState.class));
    }

    @Override
    public void configure(StateMachineTransitionConfigurer<BatteryState, BatteryEvent> t) throws Exception {
        t
            // --- dispatch on grid conditions ---
            .withExternal().source(IDLE).target(DISCHARGING).event(GRID_DEFICIT).guard(BatteryGuards.canDischarge())
            .and().withExternal().source(CHARGING).target(DISCHARGING).event(GRID_DEFICIT).guard(BatteryGuards.canDischarge())
            .and().withExternal().source(IDLE).target(CHARGING).event(GRID_SURPLUS).guard(BatteryGuards.canCharge())
            .and().withExternal().source(DISCHARGING).target(CHARGING).event(GRID_SURPLUS).guard(BatteryGuards.canCharge())
            .and().withExternal().source(CHARGING).target(IDLE).event(GRID_NORMAL)
            .and().withExternal().source(DISCHARGING).target(IDLE).event(GRID_NORMAL)
            // --- battery limits ---
            .and().withExternal().source(DISCHARGING).target(IDLE).event(SOC_LOW)
            .and().withExternal().source(CHARGING).target(IDLE).event(SOC_FULL)
            // --- faults ---
            .and().withExternal().source(IDLE).target(FAULT).event(OVER_TEMP)
            .and().withExternal().source(CHARGING).target(FAULT).event(OVER_TEMP)
            .and().withExternal().source(DISCHARGING).target(FAULT).event(OVER_TEMP)
            .and().withExternal().source(FAULT).target(IDLE).event(FAULT_CLEARED).guard(BatteryGuards.canClearFault())
            // --- connectivity ---
            .and().withExternal().source(IDLE).target(OFFLINE).event(HEARTBEAT_LOST)
            .and().withExternal().source(CHARGING).target(OFFLINE).event(HEARTBEAT_LOST)
            .and().withExternal().source(DISCHARGING).target(OFFLINE).event(HEARTBEAT_LOST)
            .and().withExternal().source(FAULT).target(OFFLINE).event(HEARTBEAT_LOST)
            .and().withExternal().source(OFFLINE).target(IDLE).event(HEARTBEAT_RESTORED);
    }
}
