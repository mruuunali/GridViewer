# Week 3: data overlays and Kafka hardening

## What was added
| Area | What |
|---|---|
| Heatmap | `leaflet.heat` layer with a toggle: **Consumption**, **Generation**, **Net balance** (red = shortfall, green = surplus), **Off**. Intensity is normalised against the highest value seen, so a storm visibly shrinks the generation glow instead of rescaling it back to full. |
| Zone detail | Click a zone: state, load ratio, generation, consumption, deficit, battery output, node counts, and a 2-minute chart (generation, load, battery output) refreshed every 2 s. |
| History API | Gateway `GET /api/zones` and `GET /api/zones/{id}/history?seconds=120`. In-memory, 1 sample/s, last 10 min per zone (long-term history and storm replay come with TimescaleDB later). |
| Dead-letter topic | `telemetry.dlq`: malformed or invalid frames from ingestion, the state engine and the stream processor are published there (payload truncated to 1 KB) instead of being dropped. Metric: `gridweaver.telemetry.dlq`. |
| Kafka tuning | `telemetry.raw`: 12 partitions (configurable via `gridweaver.kafka.telemetry-partitions`), 1-day retention, hourly segment roll so retention actually bites. DLQ: 3 partitions, 7-day retention. |
| Tooling | `scripts/kafka-lag.sh [watch]` (consumer lag + DLQ size), `scripts/dlq-peek.sh [n]`. Simulator takes a 6th argument, `badFramePct`, to inject garbage frames. |

## Run
```bash
# same services as Week 2, then:
mvn -pl gw-simulator exec:java -Dexec.args="500 ws://localhost:8080/ws/device 30 150 60 2"
#                                                                        storm^  ^len  ^2% bad frames
scripts/kafka-lag.sh watch      # consumer lag per group + dead-letter count
scripts/dlq-peek.sh 5           # see what was rejected and why
cd gw-ui && npm install && npm run dev
```
UI only: `cd gw-ui && npm run mock` (the mock now serves the history endpoint too).

## What you should see
- Heat toggle top-left. In **Net balance** before the storm the map is mostly green (surplus); when the storm hits it turns red zone by zone.
- **Generation** mode: the amber glow collapses to about 10% at the storm.
- Click any zone: panel with live numbers; the chart shows the generation cliff and the battery line rising.
- With `badFramePct=2`, `telemetry.dlq` grows (about 2% of frames), `/actuator/prometheus` shows `gridweaver_telemetry_dlq_total`, and the system keeps running normally.

## Done when
- [ ] Heatmap shifts visibly on the storm in all three modes (screenshot each)
- [ ] Zone detail chart shows the storm
- [ ] DLQ receives injected bad frames and nothing crashes
- [ ] `kafka-lag.sh` shows lag staying near zero under load (screenshot)

## Notes and limits
- Heat is per **zone**, drawn at that zone's node positions; it is not per-node interpolation.
- Partition count can be raised later but never lowered; check it before first start. If a topic already exists from an earlier week, its old settings stay until you delete it: `docker exec gw-kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --delete --topic telemetry.raw`, then restart the services.
- The stream processor now dead-letters a frame whose device type does not feed zone totals (all current types do).
- Silent devices still stay in zone totals until the tombstone work in Phase 5.
