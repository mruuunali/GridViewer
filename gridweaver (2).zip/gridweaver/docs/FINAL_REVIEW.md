# Final review runbook

Companion to the "GridWeaver Final Review" slide deck (13 slides, talk track in the speaker notes).
Target length: about 15 minutes including a 4-minute live demo.

## 1. Numbers you must collect first (the deck has bracketed placeholders)

| Slide | Cells to fill | How to get them |
|---|---|---|
| Cover | `[Your name] · [Course / guide] · [Date]` | yours |
| Concurrency audit | 12 cells (virtual / platform x threads / RSS at 10k, 25k, 50k) and `[your hardware]` | `scripts/audit.sh`, then read `audit-results.csv`. Columns: mode, target, peak_open, platform_threads, heap_mb, rss_mb, thread_create_failures. Run the platform 50k case in a VM or container (it can exhaust OS thread limits); if it fails, show the failure count instead and say so. |
| Latency | `data age` and `ingest to decision` | Run the storm demo. "data age" is the badge in the dashboard top bar. For ingest-to-decision read `curl -s localhost:8081/actuator/prometheus \| grep ingest_to_decision`: mean = `_sum` / `_count`, plus `_max`. (A 95th percentile needs percentile histograms enabled for that timer.) |
| Limits | `[your hardware]` | same machine description as the audit |

Pre-filled and real: the **1,500-connection row** on the audit slide (virtual 13 threads / 145 MB; platform 1,508 threads / 283 MB) came from a quick run in a sandbox. It is labelled as a sanity check, not a benchmark. Replace or keep it, but keep the label.
The latency "budget" column is a design estimate and is labelled as one. Do not present it as measured.

## 2. Before the room fills (15 minutes)

- [ ] `docker compose -f deploy/docker-compose.yml up -d`; `docker ps` shows `gw-kafka` and `gw-redis`
- [ ] `mvn clean install -DskipTests` succeeds (the Java modules were never compiled during development, so do this the day before, not the hour before)
- [ ] Four terminals, started in this order, each waiting for "Started ... Application":
  1. `mvn -pl gw-ingestion spring-boot:run` (8080)
  2. `mvn -pl gw-state-engine spring-boot:run` (8081)
  3. `mvn -pl gw-stream-processor spring-boot:run` (8082)
  4. `mvn -pl gw-dashboard-gateway spring-boot:run` (8090)
- [ ] `cd gw-ui && npm run dev`; open http://localhost:5173; the badge says **Live**
- [ ] Browser full screen, heatmap on **Net balance**, event log closed
- [ ] Simulator command typed in a fifth terminal, not yet run
- [ ] Dry run once end to end, then restart the simulator so zones start fresh

## 3. The live demo (about 4 minutes)

```bash
mvn -pl gw-simulator exec:java -Dexec.args="500 ws://localhost:8080/ws/device 30 150 60 0 15"
# 500 devices, storm at 30 s, 150 s total, storm lasts 60 s, 0% bad frames, storm hits zones 0-14 only
```

| Time | What happens | What to say / show |
|---|---|---|
| 0-30 s | Devices connect, map fills in | Badge "Live", "data age". Zones ignore their first 10 s on purpose (warm-up). |
| 30 s | Storm hits zones 0-14 | Outlines turn red within about a second. Read the data-age figure aloud. |
| 31-40 s | Batteries discharge; zones 5-14 borrow from sunny neighbours | Teal dashed lines. Zones 0-4 get no loan: no sunny neighbour (edge of grid / all neighbours stormed). That is correct. |
| any | Click a zone | 2-minute chart: generation cliff, battery line rising. |
| any | Event log, filter "Transfers", Export CSV | The audit trail. |
| 90 s | Storm ends | Blue (recovering), loans vanish, green about 30 s later. |

Optional extras if time allows:
- `scripts/kafka-lag.sh` and `scripts/dlq-peek.sh` (run the simulator with a 6th argument of `2` for 2% bad frames).
- Heatmap toggle: Generation shows the glow collapsing at the storm.

### Fallbacks
- **Anything fails live:** `cd gw-ui && npm run mock` replays the same storm with loans and no backend. Say plainly that it is the replay, not the live pipeline.
- **Map is empty:** the stream processor must be running before the simulator starts.
- **No red zones at 30 s:** check `curl localhost:8081/api/zones`; an empty list means zone totals are not flowing (stream processor down).
- **Tiles do not load (no internet):** the map background will be blank but nodes and zones still draw. Mention it, carry on.
- Record a 60-second screen capture of a good run beforehand as a last-resort backup.

## 4. Likely questions

| Question | Short answer |
|---|---|
| Why virtual threads and not reactive? | Same scalability, code you can read and debug. The audit isolates the threading model. |
| Did you test 100,000 connections? | Answer with your audit numbers and hardware, exactly. 100k is a multi-node target. |
| Why a separate TCP server for the audit? | Tomcat reads sockets on a few NIO threads either way; it would hide the difference. |
| What if Kafka is down? | Ingestion cannot publish; production needs a replicated cluster. Dev uses one node. |
| Biggest latency cost? | The 250 ms zone-totals refresh, by design. |
| Why not keep a state machine per battery? | Instances are heavy; the engine rebuilds one per event from a shared definition. |
| Is it secure? | Device tokens and replay protection exist (off by default in dev). No operator login yet; say so. |
| Is the Java tested? | Token signing and replay guard were run as a standalone program; the Spring and Kafka wiring needs your build and run. Be candid. |

## 5. After the review
Save `audit-results.csv`, a screenshot of the storm with the data-age badge, and the exported event-log CSV with the project report.
