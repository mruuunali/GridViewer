# Week 2: state logic, live updates, concurrency audit

## What was added
| Area | What |
|---|---|
| Load rule | `METER` devices report consumption. Zones with meters use **grid load = consumption / generation**: >= 0.8 STRESSED, >= 1.0 EMERGENCY, < 0.7 clears. Dispatch covers `consumption - generation` (+10%). Zones without meters keep the Week 1 baseline rule. |
| Gateway | `gw-dashboard-gateway` (port 8090): Kafka -> in-memory state -> **5 Hz batched deltas** over WebSocket at `/ws/dashboard`. Full snapshot on connect. Slow browsers are dropped, not waited for. |
| Live UI | `gw-ui` connects to the gateway: battery markers change colour by state, zone outlines by zone state, live totals, latest-transitions feed, connection badge and "data age" (ingestion -> browser). |
| Audit | `gw-audit` + `scripts/audit.sh`: same blocking thread-per-connection server using platform vs virtual threads at 10k / 25k / 50k connections. |

Simulator layout per zone of 10 devices: 2 batteries, 2 meters, 6 solar. Use **500 devices** so the simulator matches the 500 map nodes 1:1.

## Run the full pipeline
```bash
docker compose -f deploy/docker-compose.yml up -d
mvn clean install -DskipTests

# one terminal each
mvn -pl gw-ingestion spring-boot:run          # 8080
mvn -pl gw-state-engine spring-boot:run       # 8081
mvn -pl gw-stream-processor spring-boot:run   # 8082
mvn -pl gw-dashboard-gateway spring-boot:run  # 8090

cd gw-ui && npm install && npm run dev        # http://localhost:5173

# simulator: 500 devices, storm at 30s lasting 60s, 150s total
mvn -pl gw-simulator exec:java -Dexec.args="500 ws://localhost:8080/ws/device 30 150 60"
```
Zones ignore the first 10 s while devices connect (`warmup-ms`), so the storm should start after that.

**UI only, no backend:** `cd gw-ui && npm run mock` replays a fake storm on ws://localhost:8090 (storm at 10 s, ends at 40 s, loops every 70 s).

## What you should see
- Header badge turns green "Live", plus "data age NNN ms".
- Before the storm: green zones, blue idle batteries, grid load ~0.2-0.3.
- Storm hits: zone outlines go red within about a second, battery markers turn red (discharging), zone tooltips show load ratio > 1, the transitions feed fills up.
- Storm ends: zones go blue (RECOVERING), batteries return to blue, zones go green 30 s later.
- `curl localhost:8081/api/zones` shows mode `LOAD`, load ratio, deficit and committed power per zone.

## Mid-project review

### 1. Concurrency audit
```bash
scripts/audit.sh                       # virtual then platform at 10k, 25k, 50k -> audit-results.csv
scripts/audit.sh "10000 25000" virtual # subset
```
Columns: peak open connections, platform thread count, heap MB, RSS MB, thread-creation failures.
Run the platform case at 50k in a VM or container: it can exhaust OS thread limits.

Why a separate raw-TCP server: Tomcat's WebSocket layer does socket I/O on a few NIO selector threads
whichever executor you use, so comparing against it would hide the difference. The audit server is the
textbook thread-per-connection design, identical except for the thread type.

Sanity check run in the build sandbox (1,500 connections, 512 MB heap, one-off, not a benchmark):

| Mode | Platform threads | RSS | Failures |
|---|---|---|---|
| virtual | 13 | 145 MB | 0 |
| platform | 1,508 | 283 MB | 0 |

Your 10k-50k numbers on real hardware are what go on the slide. RSS undercounts platform threads
because stacks are committed lazily; thread count and failure count tell the clearer story at 50k.

### 2. Smooth rendering
Open the UI with the mock gateway, then in DevTools Performance record 10 s across the storm.
Target: frames stay near 60 fps, one canvas element, no per-marker DOM nodes.
For a heavier test raise `NODES_PER_ZONE` in `src/config.ts` (and update the mock/simulator ids to match).

## Done when
- [ ] Storm visibly turns zones red and batteries red in the browser, from the real backend
- [ ] `data age` stays under ~1000 ms during the storm (screenshot it)
- [ ] `audit-results.csv` for virtual and platform saved
- [ ] Frame-rate recording of the storm saved

## Known limits (deliberate, for later weeks)
- Gateway state is in memory; restart mid-storm and zone states reset to NORMAL until the next alert (Phase 5: rebuild from Redis).
- Gateway sends every update to every browser; viewport-scoped subscriptions come with larger maps.
- Solar markers don't show per-node output yet; only zone totals do.
- Batteries in the same zone cap the response; neighbour-zone dispatch is Week 4.
