# Week 1 checklist

Goal: a map of static nodes, and a backend that holds 10k concurrent connections.

## Backend (harden what exists)
1. `docker compose -f deploy/docker-compose.yml up -d`
2. `mvn clean install -DskipTests`
3. `scripts/week1-loadtest.sh 10000`
   - Raises the file-descriptor limit, starts ingestion with `-Djdk.tracePinnedThreads=full`,
     runs the simulator, and records connections / heap / threads / RSS to `week1-metrics.csv`.
4. Capture a screenshot or the CSV as your Week 1 baseline.
5. Fix anything in `/tmp/gw-ingestion.log` that reports a pinned thread.

Sandbox limit to remember: one client machine can open about 64k connections to one IP:port. 10k is
well inside that. For 50k+ in Week 2, run several simulator processes.

If you see "Too many open files" or connections stall near 1024/4096, raise limits on both ends:
`ulimit -n 200000`, `sysctl net.core.somaxconn=4096`, `sysctl net.ipv4.ip_local_port_range="10000 65535"`.

## Frontend
```bash
cd gw-ui
npm install
npm run dev        # http://localhost:5173
```
You should see a 10 x 5 grid of 50 zones with 500 nodes (300 solar in amber, 100 meters in purple, 100 batteries in blue),
hover tooltips, and a legend. Change `MAP_CENTER` in `src/config.ts` to your own city.

All markers draw on one shared canvas (`NodeLayer.tsx`), and device/zone ids use the same scheme as the
simulator (`dev-N`, `zone-0..49`), so Week 2's live updates map straight onto these markers.

## Done when
- [ ] 10,000 connections held, with baseline numbers saved
- [ ] No unexplained pinned-thread traces
- [ ] Map renders 500 static nodes and 50 zones smoothly
