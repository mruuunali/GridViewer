# Week 4: distributed balancing and polish

## What was added
| Area | What |
|---|---|
| Topology | `ZoneTopologyMap`: zones form a 10 x 5 grid (row-major, `zone-0`..`zone-49`); neighbours are the 4 orthogonal cells, no wrap-around between rows. Configurable via `gridweaver.topology.cols/rows`. PostGIS feeder topology replaces it in Phase 5; only `neighbours()` is used, so that swap is local. |
| Neighbour dispatch | When a zone's own batteries cannot cover its deficit, `ZoneController` borrows from adjacent zones that are **NORMAL**, most spare capacity first. A lender gives at most `lend-fraction` (default 0.5, rounded down) of its spare batteries, so it always keeps a reserve. Loans count toward the borrower's committed power, drop out if a battery hits its SoC floor, and are released when the borrower recovers (only the exact batteries lent, never the lender's own). |
| Transfer records | New `PowerTransfer` records on topic `grid.transfers`: lender, borrower, power, battery count, active flag. Metric: `gridweaver.zone.borrow_events`. `GET :8081/api/zones` now shows `borrowedBatteries` per zone. |
| Gateway | Consumes `grid.transfers`, sends transfers in every delta, and includes active loans in the snapshot for late-joining browsers. Loans also appear in the event log (kind `TRANSFER`). |
| Flow lines | Animated dashed lines lender -> borrower (green dot = source, red dot = sink), width grows with power. Honours reduced-motion settings. |
| Event Log panel | Topbar button opens a full audit view of every zone, battery and transfer transition: filter by type, free-text search, **Pause** (freezes the view while events keep being collected, shows how many arrived), and **Export CSV** (ISO timestamps) for auditing. Keeps the newest 2,000 entries in the browser. |
| Simulator | New 7th argument `stormZones`: the storm hits only zones `0..N-1`, so the rest stay sunny and can lend. Meter load raised (3-5 kW per meter) so a stormed zone's deficit outgrows its own 2 batteries and borrowing actually triggers. |

## Run the loan demo
```bash
# same services as Week 3, then (500 devices, storm at 30s lasting 60s, 0% bad frames, storm hits zones 0-14):
mvn -pl gw-simulator exec:java -Dexec.args="500 ws://localhost:8080/ws/device 30 150 60 0 15"
curl -s localhost:8081/api/zones | python3 -m json.tool | grep -E '"zone"|"state"|borrowed'
docker exec -it gw-kafka /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic grid.transfers
```
UI only: `cd gw-ui && npm run mock` (storm on zones 0-14, loans from the sunny neighbours).

## What you should see
- Zones 5-14 (they border sunny zones) go EMERGENCY, then a cyan dashed line animates from the sunny neighbour to each of them and the lender's battery turns red.
- Zones 0-4 go EMERGENCY with **no** loan: every neighbour is also in the storm, or off the grid edge. That is correct behaviour, and a good point to make in the demo.
- "Zone loans N active" in the stats panel; loans end and lines disappear when the borrower recovers.
- Event log shows ZONE, BATTERY and TRANSFER rows; Pause freezes it, Export CSV downloads it.

## Done when
- [ ] Loan lines appear during the storm and disappear on recovery (screenshot / short recording)
- [ ] `grid.transfers` shows start and end records for each loan
- [ ] Lender zones stay NORMAL and keep at least one battery
- [ ] Event log CSV exported and opened

## Known limits
- A lender zone's own committed-power count includes batteries it lent out (they are in its zone). If the lender itself later becomes stressed, it will think those batteries cover its deficit. Fix: track lent devices in Redis (Phase 5).
- Neighbours are grid-adjacent, not electrical (feeder-aware) neighbours yet.
- Lenders must be NORMAL. A zone in RECOVERING neither lends nor borrows until it is NORMAL again.
- Loan power is battery count x dispatch power (2 kW); it is not a metered flow.
- The Java side has not been compiled here; the topology class was tested standalone.
