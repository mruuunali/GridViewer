# Phase 5 (part 1): security and resilience

## What was added
| Area | What |
|---|---|
| Device authentication | Ingestion rejects the WebSocket upgrade with **HTTP 401** unless the device sends `Authorization: Bearer <token>`. A token is `expiry.HMAC-SHA256(secret, deviceId.expiry)`: bound to one deviceId (a token stolen from dev-1 cannot connect as dev-2), expires, and is compared in constant time. The token travels in a header, not the URL, so it stays out of access logs. Metric `gridweaver.auth.rejected`. |
| Replay protection | Per connection, a frame is accepted only if its `seq` is strictly greater than the last accepted one. Duplicated or replayed frames are dropped (metric `gridweaver.telemetry.replayed`). Gaps are fine (lost frames). |
| Tombstones | When a device disconnects, ingestion writes a null-value record for it to `telemetry.raw`. The stream processor treats it as a delete from the "latest reading" table, so a dead device **stops counting toward its zone's totals** (this was the "silent device stays in totals" limit). Only the session that is actually registered tombstones, so a stale socket replaced by a reconnect cannot erase the new connection. |
| Gateway restart | The state engine now also writes zone and battery states to Redis (`gw:zone-state`, `gw:battery-state`). The gateway reloads them at startup, so restarting it mid-storm shows EMERGENCY / DISCHARGING immediately. Best effort: if Redis is down it starts empty and catches up from Kafka. |
| Origins | Gateway WebSocket and REST accept browser origins only from `gridweaver.gateway.allowed-origins` (default `http://localhost:5173`). Edit it if you serve the UI elsewhere. |

## Turning authentication on
Auth is **off by default** so earlier demos keep working (the service logs a loud warning when it is off). To enable it:
```bash
export GW_DEVICE_SECRET='at-least-16-characters-long-and-random'   # openssl rand -base64 32
GW_DEVICE_SECRET=$GW_DEVICE_SECRET mvn -pl gw-ingestion spring-boot:run -Dspring-boot.run.arguments=--gridweaver.security.auth-enabled=true
# the simulator signs its own tokens when the same variable is set:
GW_DEVICE_SECRET=$GW_DEVICE_SECRET mvn -pl gw-simulator exec:java -Dexec.args="500 ws://localhost:8080/ws/device 30 150 60 0 15"
```
Startup fails fast if auth is enabled and the secret is shorter than 16 characters.

Make a token by hand (for curl / websocat testing); it matches the Java signer exactly:
```bash
DEV=dev-1; EXP=$(( $(date +%s) + 86400 ))
SIG=$(printf '%s' "$DEV.$EXP" | openssl dgst -sha256 -hmac "$GW_DEVICE_SECRET" -binary | openssl base64 -A | tr '+/' '-_' | tr -d '=')
echo "Authorization: Bearer $EXP.$SIG"
```

## How to check each feature
1. **Auth:** with auth on, run the simulator *without* `GW_DEVICE_SECRET`: every connection fails (the simulator's `errors` count rises, `gridweaver_auth_rejected_total` rises, nothing reaches Kafka). Run it with the secret: it works as before.
2. **Replay:** with a WebSocket client, send the same frame twice; the second is dropped (`gridweaver_telemetry_replayed_total`).
3. **Tombstones:** start 500 devices, note a zone's `solar` count at `curl localhost:8090/api/zones`, then stop the simulator: within a second or two the counts fall to zero instead of freezing at their last values.
4. **Gateway restart:** during a storm, restart only the gateway; `curl localhost:8090/api/zones` immediately shows the true zone states, and the UI recovers on reconnect.

## Tested here, and not
- **Tested:** the token signer (valid, wrong device, expired, wrong secret, forged expiry, tampered signature, empty secret) and the replay guard (duplicates, old frames, gaps, 16 threads racing on one sequence number: exactly one wins), 19 assertions, run as a standalone program and matched against an `openssl` implementation. The same cases are in `DeviceTokensTest` and `ReplayGuardTest` (JUnit, run by `mvn test`).
- **Parsed only:** all 59 Java files were checked for syntax errors (none). The Spring wiring, the Kafka tombstone path and the Redis rebuild have **not** been compiled or run; do that first.

## Still not done (honest list)
- **TimescaleDB history and storm replay.** The zone chart still uses 10 minutes of in-memory history. This is the next module (`gw-persistence`).
- **Operator login and roles (RBAC).** The dashboard WebSocket and REST are read-only but unauthenticated; the origin list is a browser-side control, not access control.
- **Command signing.** Downlink commands are not signed, so a device cannot yet verify they came from the state engine.
- **Per-device certificates (mTLS)** and secret rotation. One shared HMAC secret is simple but a single point of compromise.
- **Cross-session replay protection** (last `seq` per device in Redis) and **per-device rate limiting beyond the fixed window**.
- **Tombstone edge case:** if a device reconnects to a *different* ingestion node, the old node's tombstone can arrive after the new node's first frame; the zone briefly under-counts it until the next frame (about 1 s).
- Loans still are not tracked in Redis, so a state-engine restart forgets who lent what.
