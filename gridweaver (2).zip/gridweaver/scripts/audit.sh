#!/usr/bin/env bash
# Mid-project concurrency audit: platform threads vs virtual threads at 10k / 25k / 50k connections.
# Usage: scripts/audit.sh [sizes="10000 25000 50000"] [modes="virtual platform"]
# Output: audit-results.csv   (mode,target,peak_open,platform_threads,heap_mb,rss_mb,thread_create_failures)
#
# WARNING: the platform run at 50k can exhaust OS thread limits and freeze a laptop. Run it in a VM,
# container, or at lower sizes first. Virtual runs first by default.
set -uo pipefail
cd "$(dirname "$0")/.."
SIZES="${1:-10000 25000 50000}"
MODES="${2:-virtual platform}"
PORTS=10; BASE=9000; SECONDS_RUN=40

ulimit -n 200000 2>/dev/null || echo "WARN: could not raise ulimit -n (now $(ulimit -n))"
mvn -q -pl gw-protocol,gw-audit install -DskipTests >/dev/null || { echo "build failed"; exit 1; }

echo "mode,target,peak_open,platform_threads,heap_mb,rss_mb,thread_create_failures" > audit-results.csv
for mode in $MODES; do
  for n in $SIZES; do
    echo "== $mode @ $n connections =="
    java -Xmx1g -cp gw-audit/target/classes com.gridweaver.audit.BlockingServer "$mode" $BASE $PORTS > /tmp/audit-server.log 2>&1 &
    SERVER=$!
    sleep 2
    java -Xmx1g -cp gw-audit/target/classes com.gridweaver.audit.TcpLoadClient "$n" localhost $BASE $PORTS $SECONDS_RUN > /tmp/audit-client.log 2>&1
    # STATS,mode,open,msgs,threads,heap,rss,failures  -> take the row with the most open connections
    ROW=$(awk -F, '/^STATS/ { if ($3+0 >= m) { m=$3+0; line=$0 } } END { print line }' /tmp/audit-server.log)
    echo "$ROW" | awk -F, -v t="$n" '{ printf "%s,%s,%s,%s,%s,%s,%s\n", $2, t, $3, $5, $6, $7, $8 }' | tee -a audit-results.csv
    kill $SERVER 2>/dev/null; wait $SERVER 2>/dev/null
    sleep 5
  done
done
echo; column -s, -t audit-results.csv
