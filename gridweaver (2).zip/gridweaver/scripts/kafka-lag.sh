#!/usr/bin/env bash
# Consumer lag + dead-letter overview for the local docker Kafka.
# Usage: scripts/kafka-lag.sh [watch]     ("watch" refreshes every 5s)
KAFKA="docker exec gw-kafka /opt/kafka/bin"
show() {
  echo "=== consumer groups: lag per partition (LAG = messages not yet processed) ==="
  for g in gw-state-engine gw-zone-controller gw-zone-aggregator; do
    $KAFKA/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --describe --group "$g" 2>/dev/null
  done
  echo
  echo "=== dead-letter topic: end offset per partition (= frames dead-lettered so far) ==="
  $KAFKA/kafka-run-class.sh kafka.tools.GetOffsetShell --bootstrap-server localhost:9092 --topic telemetry.dlq 2>/dev/null
  echo
  echo "=== topic configs ==="
  $KAFKA/kafka-topics.sh --bootstrap-server localhost:9092 --describe 2>/dev/null | grep -E "^Topic:"
}
if [ "${1:-}" = "watch" ]; then while true; do clear; show; sleep 5; done; else show; fi
