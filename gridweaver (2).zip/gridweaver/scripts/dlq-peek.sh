#!/usr/bin/env bash
# Show dead-lettered frames. Usage: scripts/dlq-peek.sh [count=10]
docker exec gw-kafka /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 \
  --topic telemetry.dlq --from-beginning --max-messages "${1:-10}" --timeout-ms 5000
