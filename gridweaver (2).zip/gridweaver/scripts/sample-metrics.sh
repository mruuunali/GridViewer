#!/usr/bin/env bash
# Samples the ingestion service every 5s into a CSV: connections, heap, live threads, process RSS.
# Usage: scripts/sample-metrics.sh <ingestion-pid> [port=8080] [out=metrics.csv]
# Find the PID with: jps -l | grep gw-ingestion   (or: pgrep -f IngestionApplication)
set -euo pipefail
PID="${1:?usage: sample-metrics.sh <pid> [port] [out.csv]}"
PORT="${2:-8080}"
OUT="${3:-metrics.csv}"

metric() {  # metric <name> [tag]
  local url="http://localhost:${PORT}/actuator/metrics/$1"
  [ -n "${2:-}" ] && url="${url}?tag=$2"
  curl -s "$url" | python3 -c 'import sys,json
try:
    print(json.load(sys.stdin)["measurements"][0]["value"])
except Exception:
    print(0)'
}

echo "time,connections,heap_mb,live_threads,rss_mb" > "$OUT"
echo "sampling PID $PID on port $PORT -> $OUT (Ctrl+C to stop)"
while kill -0 "$PID" 2>/dev/null; do
  conns=$(metric gridweaver.connections.active)
  heap=$(metric jvm.memory.used area:heap | python3 -c 'import sys; print(round(float(sys.stdin.read())/1048576,1))')
  threads=$(metric jvm.threads.live)
  rss=$(ps -o rss= -p "$PID" | awk '{printf "%.1f", $1/1024}')
  echo "$(date +%T),${conns%.*},${heap},${threads%.*},${rss}" | tee -a "$OUT"
  sleep 5
done
