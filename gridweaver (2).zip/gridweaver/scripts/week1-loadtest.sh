#!/usr/bin/env bash
# Week 1 backend check: 10,000 concurrent device connections.
# Prereqs: docker compose infra up, `mvn clean install -DskipTests` done.
# Usage: scripts/week1-loadtest.sh [devices=10000]
set -euo pipefail
DEVICES="${1:-10000}"
cd "$(dirname "$0")/.."

ulimit -n 200000 2>/dev/null || echo "WARN: could not raise ulimit -n (currently $(ulimit -n)); connections may cap out"

echo "== starting ingestion with pinned-thread tracing =="
export JAVA_TOOL_OPTIONS="-Djdk.tracePinnedThreads=full -Xmx512m"
mvn -q -pl gw-ingestion spring-boot:run > /tmp/gw-ingestion.log 2>&1 &
MVN_PID=$!
trap 'kill $MVN_PID 2>/dev/null || true' EXIT

echo "waiting for ingestion on :8080 ..."
for i in $(seq 1 60); do
  curl -s localhost:8080/actuator/health | grep -q UP && break
  sleep 2
done

APP_PID=$(pgrep -f IngestionApplication | head -1)
echo "ingestion JVM pid: $APP_PID"
scripts/sample-metrics.sh "$APP_PID" 8080 week1-metrics.csv > /dev/null &
SAMPLER=$!
trap 'kill $MVN_PID $SAMPLER 2>/dev/null || true' EXIT

echo "== running simulator: $DEVICES devices for 120s =="
mvn -q -pl gw-simulator exec:java -Dexec.args="$DEVICES ws://localhost:8080/ws/device 9999 120 1"

echo
echo "== results =="
echo "metrics CSV : week1-metrics.csv"
echo "peak connections: $(awk -F, 'NR>1 && $2>m {m=$2} END {print m}' week1-metrics.csv)"
echo "peak RSS (MB)   : $(awk -F, 'NR>1 && $5>m {m=$5} END {print m}' week1-metrics.csv)"
echo "pinned-thread events in log: $(grep -c 'Thread\[#' /tmp/gw-ingestion.log || true)"
